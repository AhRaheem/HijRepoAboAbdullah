﻿using Microsoft.EntityFrameworkCore.Design;
using Microsoft.EntityFrameworkCore;

namespace Haj.EntityFramework
{
    public class TenantDbContextFactory : IDesignTimeDbContextFactory<TenantDbContext>
    {
        public TenantDbContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<TenantDbContext>();

            // Load configuration from appsettings.json
            var configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json")
                .Build();

            string connectionString;

            // Check if a full connection string is passed as an argument
            if (args.Length > 0 && args[0].Contains("Server="))
            {
                connectionString = args[0]; // Use direct connection string
            }
            else
            {
                // Otherwise, treat it as a tenant name
                var tenant = args.Length > 0 ? args[0] : "HajCompany_1"; // Default to HajCompany_1
                connectionString = configuration.GetConnectionString(tenant);
            }

            if (string.IsNullOrEmpty(connectionString))
            {
                throw new InvalidOperationException("No valid connection string found.");
            }

            optionsBuilder.UseSqlServer(connectionString);

            return new TenantDbContext(optionsBuilder.Options, connectionString);
        }
    }
}


