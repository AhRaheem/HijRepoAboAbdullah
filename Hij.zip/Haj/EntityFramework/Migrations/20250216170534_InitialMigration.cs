﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Haj.EntityFramework.Migrations
{
    /// <inheritdoc />
    public partial class InitialMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AspNetRoles",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    NormalizedName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    ConcurrencyStamp = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetRoles", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "HajContactType",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Active = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HajContactType", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "HajCountry",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    CountryCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Active = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HajCountry", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "HajCurrency",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Active = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HajCurrency", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "HajFormStatus",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Active = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HajFormStatus", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "HajFormType",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Code = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    NameAr = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    HasPayment = table.Column<bool>(type: "bit", nullable: false),
                    Active = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HajFormType", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "HajMenuItem",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Url = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Icon = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Order = table.Column<int>(type: "int", nullable: true),
                    ParentId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    RequiredPermission = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Active = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HajMenuItem", x => x.Id);
                    table.ForeignKey(
                        name: "FK_HajMenuItem_HajMenuItem_ParentId",
                        column: x => x.ParentId,
                        principalTable: "HajMenuItem",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "HajOrganizationStructure",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ParentorgStructId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    Order = table.Column<int>(type: "int", nullable: true),
                    En_SiteType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    OwnerMobileNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    OwnerName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RentValue = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    ContractStartDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ContractEndDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Phone = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Area = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Active = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HajOrganizationStructure", x => x.Id);
                    table.ForeignKey(
                        name: "FK_HajOrganizationStructure_HajOrganizationStructure_ParentorgStructId",
                        column: x => x.ParentorgStructId,
                        principalTable: "HajOrganizationStructure",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "HajPermissions",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    GroupName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ParentName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Displayname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Order = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HajPermissions", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AspNetRoleClaims",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RoleId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ClaimType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ClaimValue = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetRoleClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AspNetRoleClaims_AspNetRoles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "AspNetRoles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "HajFormTypeAction",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    FormTypeID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    Code = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    NameAr = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    NameEn = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    FromStatusCode = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ToStatusCode = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    DefaultAction = table.Column<bool>(type: "bit", nullable: true),
                    Active = table.Column<bool>(type: "bit", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HajFormTypeAction", x => x.Id);
                    table.ForeignKey(
                        name: "FK_HajFormTypeAction_HajFormType_FormTypeID",
                        column: x => x.FormTypeID,
                        principalTable: "HajFormType",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "HajFormTypesStatus",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    FormTypeID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Code = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Closed = table.Column<bool>(type: "bit", nullable: true),
                    Active = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HajFormTypesStatus", x => x.Id);
                    table.ForeignKey(
                        name: "FK_HajFormTypesStatus_HajFormType_FormTypeID",
                        column: x => x.FormTypeID,
                        principalTable: "HajFormType",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "AspNetUsers",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    VerificationCode = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Photo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    OwnerSiteId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    Active = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    UserName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    NormalizedUserName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    Email = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    NormalizedEmail = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    EmailConfirmed = table.Column<bool>(type: "bit", nullable: false),
                    PasswordHash = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SecurityStamp = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ConcurrencyStamp = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PhoneNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PhoneNumberConfirmed = table.Column<bool>(type: "bit", nullable: false),
                    TwoFactorEnabled = table.Column<bool>(type: "bit", nullable: false),
                    LockoutEnd = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    LockoutEnabled = table.Column<bool>(type: "bit", nullable: false),
                    AccessFailedCount = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUsers", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AspNetUsers_HajOrganizationStructure_OwnerSiteId",
                        column: x => x.OwnerSiteId,
                        principalTable: "HajOrganizationStructure",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "HajPermissionGrant",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    RoleName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PermissionName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    HajPermissionsId = table.Column<Guid>(type: "uniqueidentifier", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HajPermissionGrant", x => x.Id);
                    table.ForeignKey(
                        name: "FK_HajPermissionGrant_HajPermissions_HajPermissionsId",
                        column: x => x.HajPermissionsId,
                        principalTable: "HajPermissions",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "HajFormTypeActionGrant",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    RoleName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FormTypeActionId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    Active = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HajFormTypeActionGrant", x => x.Id);
                    table.ForeignKey(
                        name: "FK_HajFormTypeActionGrant_HajFormTypeAction_FormTypeActionId",
                        column: x => x.FormTypeActionId,
                        principalTable: "HajFormTypeAction",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "HajFormTypeStatusGrant",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    RoleName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    HajFormTypesStatusId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    Active = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HajFormTypeStatusGrant", x => x.Id);
                    table.ForeignKey(
                        name: "FK_HajFormTypeStatusGrant_HajFormTypesStatus_HajFormTypesStatusId",
                        column: x => x.HajFormTypesStatusId,
                        principalTable: "HajFormTypesStatus",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserClaims",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ClaimType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ClaimValue = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AspNetUserClaims_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserLogins",
                columns: table => new
                {
                    LoginProvider = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ProviderKey = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ProviderDisplayName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserId = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserLogins", x => new { x.LoginProvider, x.ProviderKey });
                    table.ForeignKey(
                        name: "FK_AspNetUserLogins_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserRoles",
                columns: table => new
                {
                    UserId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    RoleId = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserRoles", x => new { x.UserId, x.RoleId });
                    table.ForeignKey(
                        name: "FK_AspNetUserRoles_AspNetRoles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "AspNetRoles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_AspNetUserRoles_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserTokens",
                columns: table => new
                {
                    UserId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    LoginProvider = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Value = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserTokens", x => new { x.UserId, x.LoginProvider, x.Name });
                    table.ForeignKey(
                        name: "FK_AspNetUserTokens_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "HajBusinessPerson",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PhoneNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IsSupplier = table.Column<bool>(type: "bit", nullable: false),
                    CreateUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    UpdateUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    DeleteUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    CreateSiteID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    UpdateSiteID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    DeleteSiteID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    CreateTimeStamp = table.Column<DateTime>(type: "datetime2", nullable: true),
                    UpDateTimeStamp = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeleteTimeStamp = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Active = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HajBusinessPerson", x => x.Id);
                    table.ForeignKey(
                        name: "FK_HajBusinessPerson_AspNetUsers_CreateUserID",
                        column: x => x.CreateUserID,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_HajBusinessPerson_AspNetUsers_DeleteUserID",
                        column: x => x.DeleteUserID,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_HajBusinessPerson_AspNetUsers_UpdateUserID",
                        column: x => x.UpdateUserID,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_HajBusinessPerson_HajOrganizationStructure_CreateSiteID",
                        column: x => x.CreateSiteID,
                        principalTable: "HajOrganizationStructure",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_HajBusinessPerson_HajOrganizationStructure_DeleteSiteID",
                        column: x => x.DeleteSiteID,
                        principalTable: "HajOrganizationStructure",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_HajBusinessPerson_HajOrganizationStructure_UpdateSiteID",
                        column: x => x.UpdateSiteID,
                        principalTable: "HajOrganizationStructure",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "HajEmploye",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DateOfBirth = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DateOfEmployment = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Salary = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PhoneNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    NationalID = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DateOfTermination = table.Column<DateTime>(type: "datetime2", nullable: true),
                    EmergencyContactName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    EmergencyContactPhone = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BankAccountNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TaxID = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PerformanceRating = table.Column<int>(type: "int", nullable: true),
                    YearsOfExperience = table.Column<int>(type: "int", nullable: true),
                    AttendanceScore = table.Column<int>(type: "int", nullable: true),
                    EmployeUserId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    CreateUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    UpdateUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    DeleteUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    CreateSiteID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    UpdateSiteID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    DeleteSiteID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    CreateTimeStamp = table.Column<DateTime>(type: "datetime2", nullable: true),
                    UpDateTimeStamp = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeleteTimeStamp = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Active = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HajEmploye", x => x.Id);
                    table.ForeignKey(
                        name: "FK_HajEmploye_AspNetUsers_CreateUserID",
                        column: x => x.CreateUserID,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_HajEmploye_AspNetUsers_DeleteUserID",
                        column: x => x.DeleteUserID,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_HajEmploye_AspNetUsers_EmployeUserId",
                        column: x => x.EmployeUserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_HajEmploye_AspNetUsers_UpdateUserID",
                        column: x => x.UpdateUserID,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_HajEmploye_HajOrganizationStructure_CreateSiteID",
                        column: x => x.CreateSiteID,
                        principalTable: "HajOrganizationStructure",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_HajEmploye_HajOrganizationStructure_DeleteSiteID",
                        column: x => x.DeleteSiteID,
                        principalTable: "HajOrganizationStructure",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_HajEmploye_HajOrganizationStructure_UpdateSiteID",
                        column: x => x.UpdateSiteID,
                        principalTable: "HajOrganizationStructure",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "HajFormLogs",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    RelatedFormTypeId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    FromStatusId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ToStatusId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    RelatedFormId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    RelatedFormNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    UserWhoCreatedActionId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    CreateUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    UpdateUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    DeleteUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    CreateSiteID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    UpdateSiteID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    DeleteSiteID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    CreateTimeStamp = table.Column<DateTime>(type: "datetime2", nullable: true),
                    UpDateTimeStamp = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeleteTimeStamp = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Active = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HajFormLogs", x => x.Id);
                    table.ForeignKey(
                        name: "FK_HajFormLogs_AspNetUsers_CreateUserID",
                        column: x => x.CreateUserID,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_HajFormLogs_AspNetUsers_DeleteUserID",
                        column: x => x.DeleteUserID,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_HajFormLogs_AspNetUsers_UpdateUserID",
                        column: x => x.UpdateUserID,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_HajFormLogs_AspNetUsers_UserWhoCreatedActionId",
                        column: x => x.UserWhoCreatedActionId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_HajFormLogs_HajFormStatus_FromStatusId",
                        column: x => x.FromStatusId,
                        principalTable: "HajFormStatus",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_HajFormLogs_HajFormStatus_ToStatusId",
                        column: x => x.ToStatusId,
                        principalTable: "HajFormStatus",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_HajFormLogs_HajFormType_RelatedFormTypeId",
                        column: x => x.RelatedFormTypeId,
                        principalTable: "HajFormType",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_HajFormLogs_HajOrganizationStructure_CreateSiteID",
                        column: x => x.CreateSiteID,
                        principalTable: "HajOrganizationStructure",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_HajFormLogs_HajOrganizationStructure_DeleteSiteID",
                        column: x => x.DeleteSiteID,
                        principalTable: "HajOrganizationStructure",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_HajFormLogs_HajOrganizationStructure_UpdateSiteID",
                        column: x => x.UpdateSiteID,
                        principalTable: "HajOrganizationStructure",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "HajGeneralAttachment",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    RelatedEntityId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    FormTypeId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    FileName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FilePath = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ContentType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FileSize = table.Column<long>(type: "bigint", nullable: false),
                    Title = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreateUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    UpdateUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    DeleteUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    CreateSiteID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    UpdateSiteID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    DeleteSiteID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    CreateTimeStamp = table.Column<DateTime>(type: "datetime2", nullable: true),
                    UpDateTimeStamp = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeleteTimeStamp = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Active = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HajGeneralAttachment", x => x.Id);
                    table.ForeignKey(
                        name: "FK_HajGeneralAttachment_AspNetUsers_CreateUserID",
                        column: x => x.CreateUserID,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_HajGeneralAttachment_AspNetUsers_DeleteUserID",
                        column: x => x.DeleteUserID,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_HajGeneralAttachment_AspNetUsers_UpdateUserID",
                        column: x => x.UpdateUserID,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_HajGeneralAttachment_HajFormType_FormTypeId",
                        column: x => x.FormTypeId,
                        principalTable: "HajFormType",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_HajGeneralAttachment_HajOrganizationStructure_CreateSiteID",
                        column: x => x.CreateSiteID,
                        principalTable: "HajOrganizationStructure",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_HajGeneralAttachment_HajOrganizationStructure_DeleteSiteID",
                        column: x => x.DeleteSiteID,
                        principalTable: "HajOrganizationStructure",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_HajGeneralAttachment_HajOrganizationStructure_UpdateSiteID",
                        column: x => x.UpdateSiteID,
                        principalTable: "HajOrganizationStructure",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "HajBusinessPersonContactInfo",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    BusinessPersonId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    ContactTypeId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    ContactDetails = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    Active = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HajBusinessPersonContactInfo", x => x.Id);
                    table.ForeignKey(
                        name: "FK_HajBusinessPersonContactInfo_HajBusinessPerson_BusinessPersonId",
                        column: x => x.BusinessPersonId,
                        principalTable: "HajBusinessPerson",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_HajBusinessPersonContactInfo_HajContactType_ContactTypeId",
                        column: x => x.ContactTypeId,
                        principalTable: "HajContactType",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "HajEmployeContactInfo",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    EmployeId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    ContactTypeId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    ContactDetails = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    Active = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HajEmployeContactInfo", x => x.Id);
                    table.ForeignKey(
                        name: "FK_HajEmployeContactInfo_HajContactType_ContactTypeId",
                        column: x => x.ContactTypeId,
                        principalTable: "HajContactType",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_HajEmployeContactInfo_HajEmploye_EmployeId",
                        column: x => x.EmployeId,
                        principalTable: "HajEmploye",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_AspNetRoleClaims_RoleId",
                table: "AspNetRoleClaims",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "RoleNameIndex",
                table: "AspNetRoles",
                column: "NormalizedName",
                unique: true,
                filter: "[NormalizedName] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserClaims_UserId",
                table: "AspNetUserClaims",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserLogins_UserId",
                table: "AspNetUserLogins",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserRoles_RoleId",
                table: "AspNetUserRoles",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "EmailIndex",
                table: "AspNetUsers",
                column: "NormalizedEmail");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUsers_OwnerSiteId",
                table: "AspNetUsers",
                column: "OwnerSiteId");

            migrationBuilder.CreateIndex(
                name: "UserNameIndex",
                table: "AspNetUsers",
                column: "NormalizedUserName",
                unique: true,
                filter: "[NormalizedUserName] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_HajBusinessPerson_CreateSiteID",
                table: "HajBusinessPerson",
                column: "CreateSiteID");

            migrationBuilder.CreateIndex(
                name: "IX_HajBusinessPerson_CreateUserID",
                table: "HajBusinessPerson",
                column: "CreateUserID");

            migrationBuilder.CreateIndex(
                name: "IX_HajBusinessPerson_DeleteSiteID",
                table: "HajBusinessPerson",
                column: "DeleteSiteID");

            migrationBuilder.CreateIndex(
                name: "IX_HajBusinessPerson_DeleteUserID",
                table: "HajBusinessPerson",
                column: "DeleteUserID");

            migrationBuilder.CreateIndex(
                name: "IX_HajBusinessPerson_UpdateSiteID",
                table: "HajBusinessPerson",
                column: "UpdateSiteID");

            migrationBuilder.CreateIndex(
                name: "IX_HajBusinessPerson_UpdateUserID",
                table: "HajBusinessPerson",
                column: "UpdateUserID");

            migrationBuilder.CreateIndex(
                name: "IX_HajBusinessPersonContactInfo_BusinessPersonId",
                table: "HajBusinessPersonContactInfo",
                column: "BusinessPersonId");

            migrationBuilder.CreateIndex(
                name: "IX_HajBusinessPersonContactInfo_ContactTypeId",
                table: "HajBusinessPersonContactInfo",
                column: "ContactTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_HajEmploye_CreateSiteID",
                table: "HajEmploye",
                column: "CreateSiteID");

            migrationBuilder.CreateIndex(
                name: "IX_HajEmploye_CreateUserID",
                table: "HajEmploye",
                column: "CreateUserID");

            migrationBuilder.CreateIndex(
                name: "IX_HajEmploye_DeleteSiteID",
                table: "HajEmploye",
                column: "DeleteSiteID");

            migrationBuilder.CreateIndex(
                name: "IX_HajEmploye_DeleteUserID",
                table: "HajEmploye",
                column: "DeleteUserID");

            migrationBuilder.CreateIndex(
                name: "IX_HajEmploye_EmployeUserId",
                table: "HajEmploye",
                column: "EmployeUserId");

            migrationBuilder.CreateIndex(
                name: "IX_HajEmploye_UpdateSiteID",
                table: "HajEmploye",
                column: "UpdateSiteID");

            migrationBuilder.CreateIndex(
                name: "IX_HajEmploye_UpdateUserID",
                table: "HajEmploye",
                column: "UpdateUserID");

            migrationBuilder.CreateIndex(
                name: "IX_HajEmployeContactInfo_ContactTypeId",
                table: "HajEmployeContactInfo",
                column: "ContactTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_HajEmployeContactInfo_EmployeId",
                table: "HajEmployeContactInfo",
                column: "EmployeId");

            migrationBuilder.CreateIndex(
                name: "IX_HajFormLogs_CreateSiteID",
                table: "HajFormLogs",
                column: "CreateSiteID");

            migrationBuilder.CreateIndex(
                name: "IX_HajFormLogs_CreateUserID",
                table: "HajFormLogs",
                column: "CreateUserID");

            migrationBuilder.CreateIndex(
                name: "IX_HajFormLogs_DeleteSiteID",
                table: "HajFormLogs",
                column: "DeleteSiteID");

            migrationBuilder.CreateIndex(
                name: "IX_HajFormLogs_DeleteUserID",
                table: "HajFormLogs",
                column: "DeleteUserID");

            migrationBuilder.CreateIndex(
                name: "IX_HajFormLogs_FromStatusId",
                table: "HajFormLogs",
                column: "FromStatusId");

            migrationBuilder.CreateIndex(
                name: "IX_HajFormLogs_RelatedFormTypeId",
                table: "HajFormLogs",
                column: "RelatedFormTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_HajFormLogs_ToStatusId",
                table: "HajFormLogs",
                column: "ToStatusId");

            migrationBuilder.CreateIndex(
                name: "IX_HajFormLogs_UpdateSiteID",
                table: "HajFormLogs",
                column: "UpdateSiteID");

            migrationBuilder.CreateIndex(
                name: "IX_HajFormLogs_UpdateUserID",
                table: "HajFormLogs",
                column: "UpdateUserID");

            migrationBuilder.CreateIndex(
                name: "IX_HajFormLogs_UserWhoCreatedActionId",
                table: "HajFormLogs",
                column: "UserWhoCreatedActionId");

            migrationBuilder.CreateIndex(
                name: "IX_HajFormTypeAction_FormTypeID",
                table: "HajFormTypeAction",
                column: "FormTypeID");

            migrationBuilder.CreateIndex(
                name: "IX_HajFormTypeActionGrant_FormTypeActionId",
                table: "HajFormTypeActionGrant",
                column: "FormTypeActionId");

            migrationBuilder.CreateIndex(
                name: "IX_HajFormTypesStatus_FormTypeID",
                table: "HajFormTypesStatus",
                column: "FormTypeID");

            migrationBuilder.CreateIndex(
                name: "IX_HajFormTypeStatusGrant_HajFormTypesStatusId",
                table: "HajFormTypeStatusGrant",
                column: "HajFormTypesStatusId");

            migrationBuilder.CreateIndex(
                name: "IX_HajGeneralAttachment_CreateSiteID",
                table: "HajGeneralAttachment",
                column: "CreateSiteID");

            migrationBuilder.CreateIndex(
                name: "IX_HajGeneralAttachment_CreateUserID",
                table: "HajGeneralAttachment",
                column: "CreateUserID");

            migrationBuilder.CreateIndex(
                name: "IX_HajGeneralAttachment_DeleteSiteID",
                table: "HajGeneralAttachment",
                column: "DeleteSiteID");

            migrationBuilder.CreateIndex(
                name: "IX_HajGeneralAttachment_DeleteUserID",
                table: "HajGeneralAttachment",
                column: "DeleteUserID");

            migrationBuilder.CreateIndex(
                name: "IX_HajGeneralAttachment_FormTypeId",
                table: "HajGeneralAttachment",
                column: "FormTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_HajGeneralAttachment_UpdateSiteID",
                table: "HajGeneralAttachment",
                column: "UpdateSiteID");

            migrationBuilder.CreateIndex(
                name: "IX_HajGeneralAttachment_UpdateUserID",
                table: "HajGeneralAttachment",
                column: "UpdateUserID");

            migrationBuilder.CreateIndex(
                name: "IX_HajMenuItem_ParentId",
                table: "HajMenuItem",
                column: "ParentId");

            migrationBuilder.CreateIndex(
                name: "IX_HajOrganizationStructure_ParentorgStructId",
                table: "HajOrganizationStructure",
                column: "ParentorgStructId");

            migrationBuilder.CreateIndex(
                name: "IX_HajPermissionGrant_HajPermissionsId",
                table: "HajPermissionGrant",
                column: "HajPermissionsId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AspNetRoleClaims");

            migrationBuilder.DropTable(
                name: "AspNetUserClaims");

            migrationBuilder.DropTable(
                name: "AspNetUserLogins");

            migrationBuilder.DropTable(
                name: "AspNetUserRoles");

            migrationBuilder.DropTable(
                name: "AspNetUserTokens");

            migrationBuilder.DropTable(
                name: "HajBusinessPersonContactInfo");

            migrationBuilder.DropTable(
                name: "HajCountry");

            migrationBuilder.DropTable(
                name: "HajCurrency");

            migrationBuilder.DropTable(
                name: "HajEmployeContactInfo");

            migrationBuilder.DropTable(
                name: "HajFormLogs");

            migrationBuilder.DropTable(
                name: "HajFormTypeActionGrant");

            migrationBuilder.DropTable(
                name: "HajFormTypeStatusGrant");

            migrationBuilder.DropTable(
                name: "HajGeneralAttachment");

            migrationBuilder.DropTable(
                name: "HajMenuItem");

            migrationBuilder.DropTable(
                name: "HajPermissionGrant");

            migrationBuilder.DropTable(
                name: "AspNetRoles");

            migrationBuilder.DropTable(
                name: "HajBusinessPerson");

            migrationBuilder.DropTable(
                name: "HajContactType");

            migrationBuilder.DropTable(
                name: "HajEmploye");

            migrationBuilder.DropTable(
                name: "HajFormStatus");

            migrationBuilder.DropTable(
                name: "HajFormTypeAction");

            migrationBuilder.DropTable(
                name: "HajFormTypesStatus");

            migrationBuilder.DropTable(
                name: "HajPermissions");

            migrationBuilder.DropTable(
                name: "AspNetUsers");

            migrationBuilder.DropTable(
                name: "HajFormType");

            migrationBuilder.DropTable(
                name: "HajOrganizationStructure");
        }
    }
}
