﻿
using System.ComponentModel.DataAnnotations;
using System.Reflection.Metadata;
using Microsoft.EntityFrameworkCore;
using System.Reflection;
using System.Collections.Generic;
using Haj.Services;
using Haj.Domain;
using Haj.Domain.Permission;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace Haj.EntityFramework
{
    public class TenantDbContext : IdentityDbContext<AspNetUsers, IdentityRole<Guid>, Guid>
    {
            private readonly string _connectionString;

            public TenantDbContext(DbContextOptions<TenantDbContext> options) : base(options) { }

            public TenantDbContext(DbContextOptions<TenantDbContext> options, string connectionString)
                : base(options)
            {
                _connectionString = connectionString;
            }

            protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
            {
                if (!optionsBuilder.IsConfigured && !string.IsNullOrEmpty(_connectionString))
                {
                    optionsBuilder.UseSqlServer(_connectionString);
                }
            }



        public DbSet<AspNetUsers> AspNetUsers { get; set; }
        public DbSet<HajOrganizationStructure> HajOrganizationStructure { get; set; }
        public DbSet<HajPermissions> HajPermissions { get; set; }
        public DbSet<HajPermissionGrant> HajPermissionGrant { get; set; }
        public DbSet<HajMenuItem> HajMenuItem { get; set; }
        public DbSet<HajFormType> HajFormType { get; set; }
        public DbSet<HajFormStatus> HajFormStatus { get; set; }
        public DbSet<HajFormTypesStatus> HajFormTypesStatus { get; set; }
        public DbSet<HajFormTypeAction> HajFormTypeAction { get; set; }
        public DbSet<HajFormTypeActionGrant> HajFormTypeActionGrant { get; set; }
        public DbSet<HajFormTypeStatusGrant> HajFormTypeStatusGrant { get; set; }
        public DbSet<HajCountry> HajCountry { get; set; }
        public DbSet<HajEmploye> HajEmploye { get; set; }
        public DbSet<HajBusinessPerson> HajBusinessPerson { get; set; }
        public DbSet<HajBusinessPersonContactInfo> HajBusinessPersonContactInfo { get; set; }
        public DbSet<HajEmployeContactInfo> HajEmployeContactInfo { get; set; }
        public DbSet<HajCurrency> HajCurrency { get; set; }
        public DbSet<HajGeneralAttachment> HajGeneralAttachment { get; set; }
        public DbSet<HajFormLogs> HajFormLogs { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<HajFormLogs>()
                  .HasOne(p => p.FromStatus)
                  .WithMany()
                  .HasForeignKey(p => p.FromStatusId)
                  .OnDelete(DeleteBehavior.Restrict); // Prevent cascading deletes

            modelBuilder.Entity<HajFormLogs>()
                .HasOne(p => p.ToStatus)
                .WithMany()
                .HasForeignKey(p => p.ToStatusId)
                .OnDelete(DeleteBehavior.Restrict); // Prevent cascading deletes

            modelBuilder.Entity<HajPermissions>()
               .HasKey(rp => new { rp.Id });

            base.OnModelCreating(modelBuilder);



            foreach (var entityType in modelBuilder.Model.GetEntityTypes())
            {
                if (typeof(AuditableEntity).IsAssignableFrom(entityType.ClrType))
                {
                    var builder = modelBuilder.Entity(entityType.ClrType);

                    builder.HasOne("CreateUser")
                           .WithMany()
                           .HasForeignKey("CreateUserID")
                           .OnDelete(DeleteBehavior.Restrict);

                    builder.HasOne("UpdateUser")
                           .WithMany()
                           .HasForeignKey("UpdateUserID")
                           .OnDelete(DeleteBehavior.Restrict);

                    builder.HasOne("DeleteUser")
                           .WithMany()
                           .HasForeignKey("DeleteUserID")
                           .OnDelete(DeleteBehavior.Restrict);

                }
            }

        }
    }
}
