﻿namespace Haj.Domain.Shared.Enums
{
    public class ConstantDto
    {
        public string Key { get; set; } // The constant name
        public string Value { get; set; } // The constant value
    }
}
