﻿namespace Haj.Domain.Shared.Enums
{
    public class ConstantsHelper
    {
        public static List<ConstantDto> GetConstants<T>() where T : class
        {
            var constants = typeof(T).GetFields(System.Reflection.BindingFlags.Public |
                                                System.Reflection.BindingFlags.Static |
                                                System.Reflection.BindingFlags.FlattenHierarchy)
                                      .Where(f => f.IsLiteral && !f.IsInitOnly) // Filters constants
                                      .Select(f => new ConstantDto
                                      {
                                          Key = f.Name,
                                          Value = f.GetRawConstantValue()?.ToString()
                                      })
                                      .ToList();

            return constants;
        }
    }
       
}
