﻿using System.Net.Sockets;
using System.Net;

namespace Haj.Services.CurrentUser
{
    public class CurrentIPHost : ICurrentIPHost
    {
        public string GetIpHost()
        {
            string PcIP = "";
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    PcIP = ip.ToString();
                }
            }
            return PcIP;
        }
    }
}
