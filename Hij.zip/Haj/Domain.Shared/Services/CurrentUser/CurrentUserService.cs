﻿using Microsoft.AspNetCore.Http;
using System.Security.Claims;
using System.ComponentModel.DataAnnotations;
using System.IdentityModel.Tokens.Jwt;
using Haj.Domain;
using Microsoft.AspNetCore.Identity;
namespace Haj.Services
{
    
    public class CurrentUserService : ICurrentUserService
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        public CurrentUserService(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }
        public  string GetUserID()
        {
            string userId= _httpContextAccessor.HttpContext.User?.FindFirstValue(JwtRegisteredClaimNames.Jti);
            return  userId;
        }
        public string GetSiteID()
        {
            string siteId= _httpContextAccessor.HttpContext.User?.FindFirstValue(JwtRegisteredClaimNames.Aud);
            return siteId;
        }
        public string GetCompanyId()
        {
            var claimsIdentity = _httpContextAccessor.HttpContext?.User.Identity as ClaimsIdentity;
            return claimsIdentity?.FindFirst("CompanyId")?.Value;
        }
        public DateTime GetDateTime()
        {
            return DateTime.Now;
        }
        public bool IsAuthenticated()
        {
            return _httpContextAccessor.HttpContext.User.Identity.IsAuthenticated;
        }
    }
}
