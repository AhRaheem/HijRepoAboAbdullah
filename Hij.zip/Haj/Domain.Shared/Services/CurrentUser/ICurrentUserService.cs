﻿using System.ComponentModel.DataAnnotations;
namespace Haj.Services
{
    public interface ICurrentUserService
    {
        string GetUserID();
        string GetSiteID();
        DateTime GetDateTime();
        string GetCompanyId();
        bool IsAuthenticated();
    }
}
