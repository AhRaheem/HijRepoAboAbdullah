﻿using Haj.ApplicationContracts.HajFormStatusDT;

namespace Haj.Domain.Shared.Services.CurrentUser
{
    public class CurrentUserData
    {
        public string LoginName { get; set; }
        public string Email { get; set; }
        public string? Photo { get; set; }
        public List<string> RoleName { get; set; }
        public List<string> permsiisons { get; set; }
        public string SiteName { get; set; }
        public string? ParentSiteName { get; set; }
        public List<Guid?> Actions { get; set; }
        public List<Guid?> FromTypeId { get; set; }
        public List<FormTypeAndStatusDto> FormTypeandStatusGrant { get; set; }

    }
}
