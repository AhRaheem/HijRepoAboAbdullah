﻿using Haj.ApplicationContracts.AspIdentityRoleDT;
using Haj.ApplicationContracts.HajFormStatusDT;
using Haj.EntityFramework;
using Haj.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace Haj.Domain.Shared.Services.CurrentUser
{
    public class UserActionAndStatusService
    {
        private readonly UserManager<AspNetUsers> _userManager;
        public readonly TenantDbContext _context;
        public ICurrentUserService currentUser;
     
        public UserActionAndStatusService(UserManager<AspNetUsers> userManager, TenantDbContext context, ICurrentUserService currentUser)
        {
            _userManager = userManager;
            _context = context;
            this.currentUser = currentUser;
        }
        public async Task<CurrentUserData> GetUser()
        {
            var userId = currentUser.GetUserID();
            var user2 = await _userManager.FindByIdAsync(userId);
            var roles = await _userManager.GetRolesAsync(user2);
            List<string> roleList = roles.ToList();

            var usHajermission = await GetUsHajermissionsAsync(user2);

            List<Guid?> actions = await _context.HajFormTypeActionGrant
                .Where(x => roles.Contains(x.RoleName))
                .Select(x => x.FormTypeActionId)
                .ToListAsync();

            List<Guid?> HajFormTypesStatusId = await _context.HajFormTypeStatusGrant
                .Where(x => roles.Contains(x.RoleName))
                .Select(x => x.HajFormTypesStatusId)
                .ToListAsync();

            // Using JOIN instead of a subquery to fetch FormStatusId efficiently
            var FormType = await (from formTypeStatus in _context.HajFormTypesStatus
                                  join formStatus in _context.HajFormStatus
                                      on formTypeStatus.Code equals formStatus.Name
                                  join formType in _context.HajFormType 
                                      on formTypeStatus.FormTypeID equals formType.Id
                                  where HajFormTypesStatusId.Contains(formTypeStatus.Id)
                                  select new FormTypeAndStatusDto
                                  {
                                      FormTypeId = formTypeStatus.FormTypeID,
                                      FormStatusId = formStatus.Id
                                  })
                      .Distinct()
                      .ToListAsync();

            return new CurrentUserData
            {
                LoginName = user2.FirstName + " " + user2.LastName,
                Email = user2.Email,
                Photo = user2.Photo,
                RoleName = roleList,
                permsiisons = usHajermission,
                Actions = actions,
                FormTypeandStatusGrant = FormType
            };
        }

        public async Task<List<string>> GetUsHajermissionsAsync(AspNetUsers user)
        {
            // Get roles assigned to the user
            var roles = await _userManager.GetRolesAsync(user);
            var permissions = new List<string>();

            // Fetch permissions based on the roles
            foreach (var role in roles)
            {
                var rolePermissions = await _context.HajPermissionGrant
                    .Where(pg => pg.RoleName == role)
                    .Select(pg => pg.PermissionName)
                    .ToListAsync();

                permissions.AddRange(rolePermissions);
            }

            return permissions.Distinct().ToList(); // Return distinct permissions
        }
    }
}
