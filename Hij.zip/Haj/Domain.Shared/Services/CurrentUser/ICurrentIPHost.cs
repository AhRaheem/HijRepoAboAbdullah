﻿namespace Haj.Services
{
    public interface ICurrentIPHost
    {
        string GetIpHost();
    }
}
