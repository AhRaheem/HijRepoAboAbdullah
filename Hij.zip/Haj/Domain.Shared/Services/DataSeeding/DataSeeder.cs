﻿using Haj.Domain;
using Haj.Domain.Permission;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Security;
using System.Data;
using Microsoft.EntityFrameworkCore;
using Haj.EntityFramework;
using Haj.Domain.Shared.Services.enums;
using System.Reflection;
using static System.Net.Mime.MediaTypeNames;
using System.Security.Cryptography.Xml;
using static System.Runtime.InteropServices.JavaScript.JSType;
using Microsoft.AspNetCore.Http.HttpResults;

public class DataSeeder
{
    private readonly IServiceProvider _serviceProvider;
    private readonly ILogger<DataSeeder> _logger;
    private readonly Dictionary<string, string> _tenantConnections;

    public DataSeeder(IServiceProvider serviceProvider, ILogger<DataSeeder> logger)
    {
        _serviceProvider = serviceProvider;
        _logger = logger;

        // 🔹 Define tenant connection strings (modify as needed)
        _tenantConnections = new Dictionary<string, string>
        {
            { "HajCompany_1", "Server=.;Database=HajCompany_1;Trusted_Connection=True;encrypt=false;MultipleActiveResultSets=true" },
            { "HajCompany_2", "Server=.;Database=HajCompany_2;Trusted_Connection=True;encrypt=false;MultipleActiveResultSets=true" }
        };
    }

    public async Task SeedRolesAndPermissionsAndUserAsync()
    {
        try
        {
            var tenantConnections = new Dictionary<string, string>
        {
           // { "HajCompany_1", "Server=.;Database=HajCompany_1;Trusted_Connection=True;encrypt=false;MultipleActiveResultSets=true" },
            { "HajCompany_2", "Server=.;Database=HajCompany_2;Trusted_Connection=True;encrypt=false;MultipleActiveResultSets=true" }
        };

            foreach (var (tenant, connectionString) in tenantConnections)
            {
                _logger.LogInformation($"Seeding data for {tenant}...");

                using (var scope = _serviceProvider.CreateScope())
                {
                    var roleManager = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole<Guid>>>();

                    // Manually create a new DbContext for each tenant
                    var dbContextOptions = new DbContextOptionsBuilder<TenantDbContext>()
                        .UseSqlServer(connectionString)
                        .Options;

                    using (var dbContext = new TenantDbContext(dbContextOptions, connectionString))
                    {
                        await SeedUserAsync(scope.ServiceProvider, dbContext);
                        await SeedRolesAsync(roleManager);
                        await SeedUserRoleAsync(scope.ServiceProvider, dbContext, roleManager);
                        await SeedPermissionsAsync(dbContext, roleManager);
                        await SeedPermissionGrantAsync(dbContext, roleManager);
                        await SeedMenuAsync(dbContext);
                    }
                }

                _logger.LogInformation($"Seeding completed for {tenant}.");
            }


        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error seeding roles and permissions.");
        }
    }

    private async Task SeedUserAsync(IServiceProvider serviceProvider, TenantDbContext context)
    {
        var userManager = serviceProvider.GetRequiredService<UserManager<AspNetUsers>>();

        var checkSite = await context.HajOrganizationStructure.ToListAsync();
        if (!checkSite.Any())
        {
            var site = new HajOrganizationStructure
            {
                Name = "organization",
                Order = 1,
                En_SiteType = HajSiteType.MainOrganization,
                Active = true
            };

            context.HajOrganizationStructure.Add(site);
            await context.SaveChangesAsync();
        }

        var checkUser = await context.AspNetUsers.ToListAsync();
        if (checkUser.Count == 0)
        {
            var site = await context.HajOrganizationStructure.FirstOrDefaultAsync(x => x.Name == "organization");
            if (site == null)
            {
                _logger.LogError("Failed to find organization site.");
                return;
            }

            var user = new AspNetUsers
            {
                Id = Guid.NewGuid(),
                UserName = "Admin",
                Email = "admin@gmail.com",
                FirstName = "Omar",
                LastName = "Magdy",
                OwnerSiteId = site.Id
            };
            
            var result = await userManager.CreateAsync(user, "P@ssw0rd");

            if (result.Succeeded)
            {
                _logger.LogInformation($"User '{user.UserName}' created successfully.");
            }
            else
            {
                _logger.LogError($"Error creating user: {string.Join(", ", result.Errors.Select(e => e.Description))}");
            }
        }
    }

    private async Task SeedRolesAsync(RoleManager<IdentityRole<Guid>> roleManager)
    {
        // Define your roles
        string[] roles = { "Admin", "User", "Manager" };

        foreach (var role in roles)
        {
            // Check if the role already exists
            if (!await roleManager.RoleExistsAsync(role))
            {
                // Create a new IdentityRole with Guid as the Id type
                var identityRole = new IdentityRole<Guid>(role);
                await roleManager.CreateAsync(identityRole);
                _logger.LogInformation($"Role '{role}' created.");
            }
            else
            {
                _logger.LogInformation($"Role '{role}' already exists.");
            }
        }
    }
    private async Task SeedUserRoleAsync(IServiceProvider serviceProvider, TenantDbContext context, RoleManager<IdentityRole<Guid>> roleManager)
    {
        var userManager = serviceProvider.GetRequiredService<UserManager<AspNetUsers>>();
        var checkUser = await userManager.FindByNameAsync("Admin");
        var adminRole = await roleManager.FindByNameAsync("Admin");
        var CheckUserRole = await userManager.IsInRoleAsync(checkUser, adminRole.Name);
        if (CheckUserRole is false)
        {
            var result = await userManager.AddToRoleAsync(checkUser, adminRole.Name);
            if (result.Succeeded)
            {
                _logger.LogInformation($"User '{checkUser.UserName}' createdRole.");
            }
            else
            {
                _logger.LogError("Error seeding userRole.");
            }
        }


    }
    private async Task SeedPermissionsAsync(TenantDbContext context, RoleManager<IdentityRole<Guid>> roleManager)
    {
        
        var permissionsSetting = new List<HajPermissions>
        {
              new HajPermissions {
                Name = HajPermissionsData.BackofficeGroup ,
                Displayname="تخطيط موارد المؤسسة"
            },

              new HajPermissions {
                GroupName=HajPermissionsData.GroupName,
                Name = HajPermissionsData.SettingsPermissions.SettingsNode,
                Displayname="الإعدادات",
                ParentName=HajPermissionsData.BackofficeGroup,
                Order=1

            },
              new HajPermissions {
                GroupName = HajPermissionsData.GroupName,
                Name = HajPermissionsData.SettingsPermissions.LookupsNode,
                Displayname="المراجع",
                ParentName = HajPermissionsData.SettingsPermissions.SettingsNode,

            },
              new HajPermissions {
                GroupName =HajPermissionsData.GroupName,
                Name = HajPermissionsData.SettingsPermissions.LookupsPermissions.Create,
                Displayname="إنشاء المراجع",
                ParentName =HajPermissionsData.SettingsPermissions.LookupsNode,
            },
              new HajPermissions {
                GroupName =HajPermissionsData.GroupName,
                Name = HajPermissionsData.SettingsPermissions.LookupsPermissions.Update,
                Displayname="تعديل المراجع",
                ParentName =HajPermissionsData.SettingsPermissions.LookupsNode,
            },
              new HajPermissions {
                GroupName =HajPermissionsData.GroupName,
                Name = HajPermissionsData.SettingsPermissions.LookupsPermissions.Remove,
                Displayname="حذف المراجع",
                ParentName =HajPermissionsData.SettingsPermissions.LookupsNode,
            },

              new HajPermissions {
                GroupName=HajPermissionsData.GroupName,
                Name = HajPermissionsData.SettingsPermissions.AccountNode,
                Displayname="أعدادات المستخدمين والادوار",
                ParentName=HajPermissionsData.BackofficeGroup,
                Order=1

            },

              new HajPermissions {
                GroupName=HajPermissionsData.GroupName,
                Name = HajPermissionsData.SettingsPermissions.UserNode,
                Displayname="المستخدمين",
                ParentName=HajPermissionsData.SettingsPermissions.AccountNode,
                Order=1

            },
              new HajPermissions {
                GroupName =HajPermissionsData.GroupName,
                Name = HajPermissionsData.SettingsPermissions.UsHajermissions.Create,
                Displayname="إنشاء المستخدمين",
                ParentName =HajPermissionsData.SettingsPermissions.UserNode,
            },
              new HajPermissions {
                GroupName =HajPermissionsData.GroupName,
                Name = HajPermissionsData.SettingsPermissions.UsHajermissions.Update,
                Displayname="تعديل المستخدمين",
                ParentName =HajPermissionsData.SettingsPermissions.UserNode,
            },
              new HajPermissions {
                GroupName =HajPermissionsData.GroupName,
                Name = HajPermissionsData.SettingsPermissions.UsHajermissions.Remove,
                Displayname="حذف المستخدمين",
                ParentName =HajPermissionsData.SettingsPermissions.UserNode,
            },

              new HajPermissions {
                GroupName=HajPermissionsData.GroupName,
                Name = HajPermissionsData.SettingsPermissions.RoleNode,
                Displayname="الصلاحيات",
                ParentName=HajPermissionsData.SettingsPermissions.AccountNode,
                Order=1

            },
              new HajPermissions {
                GroupName =HajPermissionsData.GroupName,
                Name = HajPermissionsData.SettingsPermissions.RolePermissions.Create,
                Displayname="إنشاء الصلاحيات",
                ParentName =HajPermissionsData.SettingsPermissions.RoleNode,
            },
              new HajPermissions {
                GroupName =HajPermissionsData.GroupName,
                Name = HajPermissionsData.SettingsPermissions.RolePermissions.Update,
                Displayname="تعديل الصلاحيات",
                ParentName =HajPermissionsData.SettingsPermissions.RoleNode,
            },
              new HajPermissions {
                GroupName =HajPermissionsData.GroupName,
                Name = HajPermissionsData.SettingsPermissions.RolePermissions.Remove,
                Displayname="حذف الصلاحيات",
                ParentName =HajPermissionsData.SettingsPermissions.RoleNode,
            },


              new HajPermissions {
                GroupName=HajPermissionsData.GroupName,
                Name = HajPermissionsData.SettingsPermissions.RolePermissionNode,
                Displayname="إعدادات السماح للادوار",
                ParentName=HajPermissionsData.SettingsPermissions.AccountNode,
                Order=1

            },
              new HajPermissions {
                GroupName =HajPermissionsData.GroupName,
                Name = HajPermissionsData.SettingsPermissions.RolePermissionPermissions.Create,
                Displayname="إنشاء سماحية الادوار",
                ParentName =HajPermissionsData.SettingsPermissions.RolePermissionNode,
            },
              new HajPermissions {
                GroupName =HajPermissionsData.GroupName,
                Name = HajPermissionsData.SettingsPermissions.RolePermissionPermissions.Update,
                Displayname="تعديل سماحية الادوار",
                ParentName =HajPermissionsData.SettingsPermissions.RolePermissionNode,
            },
              new HajPermissions {
                GroupName =HajPermissionsData.GroupName,
                Name = HajPermissionsData.SettingsPermissions.RolePermissionPermissions.Remove,
                Displayname="حذف سماحية الادوار",
                ParentName =HajPermissionsData.SettingsPermissions.RolePermissionNode,
            },


              new HajPermissions {
                GroupName=HajPermissionsData.GroupName,
                Name = HajPermissionsData.SettingsPermissions.UserRoleNode,
                Displayname="إعدادات أدوار للمستخدمين",
                ParentName=HajPermissionsData.SettingsPermissions.AccountNode,
                Order=1

            },
              new HajPermissions {
                GroupName =HajPermissionsData.GroupName,
                Name = HajPermissionsData.SettingsPermissions.UserRolePermissions.Create,
                Displayname="إنشاء أدوار للمستخدمين",
                ParentName =HajPermissionsData.SettingsPermissions.UserRoleNode,
            },
              new HajPermissions {
                GroupName =HajPermissionsData.GroupName,
                Name = HajPermissionsData.SettingsPermissions.UserRolePermissions.Update,
                Displayname="تعديل أدوار للمستخدمين",
                ParentName =HajPermissionsData.SettingsPermissions.UserRoleNode,
            },
              new HajPermissions {
                GroupName =HajPermissionsData.GroupName,
                Name = HajPermissionsData.SettingsPermissions.UserRolePermissions.Remove,
                Displayname="حذف أدوار للمستخدمين",
                ParentName =HajPermissionsData.SettingsPermissions.UserRoleNode,
            },

        };

            foreach (var permission in permissionsSetting)
            {
                if (!context.HajPermissions.Any(p => p.Name == permission.Name))
                {
                    permission.Id = Guid.NewGuid();
                    context.HajPermissions.Add(permission);
                    _logger.LogInformation($"Permission '{permission.Name}' added.");
                }
            }
        context.SaveChangesAsync();
    }
    private async Task SeedPermissionGrantAsync(TenantDbContext context, RoleManager<IdentityRole<Guid>> roleManager)
    {
        var adminRole = context.Roles.Where(x => x.Name == "Admin").FirstOrDefault();
        var permissions = context.HajPermissions.ToList();
        foreach (var perm in permissions)
        {
            if (!context.HajPermissionGrant.Any(x => x.PermissionName == perm.Name && x.RoleName == adminRole.Name))
            {
                var permGrant = new HajPermissionGrant { Id = Guid.NewGuid(), PermissionName = perm.Name, RoleName = adminRole.Name };
                context.HajPermissionGrant.Add(permGrant);
            }
        }
        context.SaveChanges();
    }
    private async Task SeedMenuAsync(TenantDbContext context)
    {
        
        #region ShareSetting 
            var ParentMenu = new List<HajMenuItem>
            {
                new HajMenuItem
    {
        Id = Guid.NewGuid(),
        Name = "Settings",
        Url = "Haj-contact-type",
        Icon = "settings",
        Order = 1,   
        RequiredPermission=HajPermissionsData.SettingsPermissions.LookupsNode,
        Active=true,
        IsDeleted=false
    },
                           new HajMenuItem
    {
        Id = Guid.NewGuid(),
        Name = "Account",
        Url = "Haj-Permission",
        Icon = "settings",
        Order = 2,
       
        RequiredPermission=HajPermissionsData.SettingsPermissions.AccountNode,
        Active=true,
        IsDeleted=false
    }
            };
            foreach (var item1 in ParentMenu)
            {
                if (!context.HajMenuItem.Any(x => x.Name == item1.Name))
                {
                    HajMenuItem HajMenu = new HajMenuItem
                    {
                        Id = Guid.NewGuid(),
                        Icon = item1.Icon,
                        Order = item1.Order,
                        Name = item1.Name,
                        Url = item1.Url,
                        ParentId = item1.ParentId,
                        RequiredPermission = item1.RequiredPermission,
                    };
                    context.HajMenuItem.Add(HajMenu);
                }
            }
            context.SaveChanges();
            var MenuSetting = new List<HajMenuItem> {

                new HajMenuItem
    {
        Id = Guid.NewGuid(),
        Name = "Contact Type",
        Url = "Haj-contact-type",
        Icon = "contacts",
        Order = 1,
        ParentId = context.HajMenuItem.FirstOrDefault(m => m.Name == "Settings")?.Id,
       
        RequiredPermission=HajPermissionsData.SettingsPermissions.LookupsNode,
        Active=true,
        IsDeleted=false
    },
                new HajMenuItem
    {
        Id = Guid.NewGuid(),
        Name = "Department",
        Url = "Haj-department",
        Icon = "office-building",
        Order = 2,
        ParentId = context.HajMenuItem.FirstOrDefault(m => m.Name == "Settings")?.Id,
       
        RequiredPermission=HajPermissionsData.SettingsPermissions.LookupsNode,
        Active=true,
        IsDeleted=false
    },
                new HajMenuItem
    {
        Id = Guid.NewGuid(),
        Name = "Country",
        Url = "Haj-country",
        Icon = "flag",
        Order = 3,
        ParentId = context.HajMenuItem.FirstOrDefault(m => m.Name == "Settings")?.Id,
       
        RequiredPermission=HajPermissionsData.SettingsPermissions.LookupsNode,
        Active=true,
        IsDeleted=false
    },
                new HajMenuItem
    {
        Id = Guid.NewGuid(),
        Name = "Job",
        Url = "Haj-job",
        Icon = "work",
        Order = 4,
        ParentId = context.HajMenuItem.FirstOrDefault(m => m.Name == "Settings")?.Id,
       
        RequiredPermission=HajPermissionsData.SettingsPermissions.LookupsNode,
        Active=true,
        IsDeleted=false
    },
                new HajMenuItem
    {
        Id = Guid.NewGuid(),
        Name = "Document Types",
        Url = "Haj-document-type",
        Icon = "folder",
        Order = 5,
        ParentId = context.HajMenuItem.FirstOrDefault(m => m.Name == "Settings")?.Id,
       
        RequiredPermission=HajPermissionsData.SettingsPermissions.LookupsNode,
        Active=true,
        IsDeleted=false
    },
                new HajMenuItem
    {
        Id = Guid.NewGuid(),
        Name = "Teams",
        Url = "Haj-team",
        Icon = "group",
        Order = 6,
        ParentId = context.HajMenuItem.FirstOrDefault(m => m.Name == "Settings")?.Id,
       
        RequiredPermission=HajPermissionsData.SettingsPermissions.LookupsNode,
        Active=true,
        IsDeleted=false
    },
                new HajMenuItem
    {
        Id = Guid.NewGuid(),
        Name = "Employe",
        Url = "Haj-employe",
        Icon = "person",
        Order = 7,
        ParentId = context.HajMenuItem.FirstOrDefault(m => m.Name == "Settings")?.Id,
       
        RequiredPermission=HajPermissionsData.SettingsPermissions.LookupsNode,
        Active=true,
        IsDeleted=false
    },
                new HajMenuItem
    {
        Id = Guid.NewGuid(),
        Name = "BusinessPerson",
        Url = "Haj-businessperson",
        Icon = "settings",
        Order = 8,
        ParentId = context.HajMenuItem.FirstOrDefault(m => m.Name == "Settings")?.Id,
       
        RequiredPermission=HajPermissionsData.SettingsPermissions.LookupsNode,
        Active=true,
        IsDeleted=false
    },
                new HajMenuItem
    {
        Id = Guid.NewGuid(),
        Name = "Currency",
        Url = "Haj-currency",
        Icon = "settings",
        Order = 9,
        ParentId = context.HajMenuItem.FirstOrDefault(m => m.Name == "Settings")?.Id,
       
        RequiredPermission=HajPermissionsData.SettingsPermissions.LookupsNode,
        Active=true,
        IsDeleted=false
    },
                new HajMenuItem
    {
        Id = Guid.NewGuid(),
        Name = "CommitteeJob",
        Url = "Haj-committeejob",
        Icon = "settings",
        Order = 10,
        ParentId = context.HajMenuItem.FirstOrDefault(m => m.Name == "Settings")?.Id,
       
        RequiredPermission=HajPermissionsData.SettingsPermissions.LookupsNode,
        Active=true,
        IsDeleted=false
    },
                new HajMenuItem
    {
        Id = Guid.NewGuid(),
        Name = "OrganizationStructure",
        Url = "Haj-organizationstructure",
        Icon = "settings",
        Order = 11,
        ParentId = context.HajMenuItem.FirstOrDefault(m => m.Name == "Settings")?.Id,
       
        RequiredPermission=HajPermissionsData.SettingsPermissions.LookupsNode,
        Active=true,
        IsDeleted=false
    },
                new HajMenuItem
    {
        Id = Guid.NewGuid(),
        Name = "AccountingPeriod",
        Url = "Haj-accounting-period",
        Icon = "settings",
        Order = 12,
        ParentId = context.HajMenuItem.FirstOrDefault(m => m.Name == "Settings")?.Id,
       
        RequiredPermission=HajPermissionsData.SettingsPermissions.LookupsNode,
        Active=true,
        IsDeleted=false
    },
                new HajMenuItem
    {
        Id = Guid.NewGuid(),
        Name = "Menu",
        Url = "Haj-menu",
        Icon = "settings",
        Order = 12,
        ParentId = context.HajMenuItem.FirstOrDefault(m => m.Name == "Settings")?.Id,
       
        RequiredPermission=HajPermissionsData.SettingsPermissions.LookupsNode,
        Active=true,
        IsDeleted=false
    },
              new HajMenuItem
    {
        Id = Guid.NewGuid(),
        Name = "Users",
        Url = "users",
        Icon = "settings",
        Order = 1,
        ParentId = context.HajMenuItem.FirstOrDefault(m => m.Name == "Account")?.Id,
       
        RequiredPermission=HajPermissionsData.SettingsPermissions.UserNode,
        Active=true,
        IsDeleted=false
    }  ,
              new HajMenuItem
    {
        Id = Guid.NewGuid(),
        Name = "UserRole",
        Url = "users",
        Icon = "settings",
        Order = 2,
        ParentId = context.HajMenuItem.FirstOrDefault(m => m.Name == "Account")?.Id,
       
        RequiredPermission=HajPermissionsData.SettingsPermissions.UserRoleNode,
        Active=true,
        IsDeleted=false
    },
                new HajMenuItem
    {
        Id = Guid.NewGuid(),
        Name = "Roles",
        Url = "roles",
        Icon = "settings",
        Order = 3,
        ParentId = context.HajMenuItem.FirstOrDefault(m => m.Name == "Account")?.Id,
       
        RequiredPermission=HajPermissionsData.SettingsPermissions.RoleNode,
        Active=true,
        IsDeleted=false
    },
                new HajMenuItem
    {
        Id = Guid.NewGuid(),
        Name = "RolePermission",
        Url = "rolepermission",
        Icon = "settings",
        Order = 4,
        ParentId = context.HajMenuItem.FirstOrDefault(m => m.Name == "Account")?.Id,
       
        RequiredPermission=HajPermissionsData.SettingsPermissions.LookupsNode,
        Active=true,
        IsDeleted=false
    }

            };
            foreach (var item in MenuSetting)
            {
                if (!context.HajMenuItem.Any(x => x.Name == item.Name))
                {
                    HajMenuItem HajMenu = new HajMenuItem
                    {
                        Id = Guid.NewGuid(),
                        Icon = item.Icon,
                        Order = item.Order,
                        Name = item.Name,
                        Url = item.Url,
                       
                        ParentId = item.ParentId,
                        RequiredPermission = item.RequiredPermission,
                    };
                    context.HajMenuItem.Add(HajMenu);
                }
                context.SaveChanges();
            }
        #endregion
    }
}


