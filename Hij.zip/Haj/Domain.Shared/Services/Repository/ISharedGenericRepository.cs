﻿using Haj.Services;
using Haj.Wrappers;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

public interface ISharedGenericRepository<T, TDto, TPostDto, TPutDto>
    where T : class
    where TPostDto : class
    where TPutDto : IHasId // Ensure TPutDto implements an Id property
    where TDto : class, new() // Ensure TDto can be instantiated
{
    ISharedGenericRepository<T, TDto, TPostDto, TPutDto> Include(params Expression<Func<T, object>>[] includes);
    public ISharedGenericRepository<T, TDto, TPostDto, TPutDto> ThenInclude<TPreviousEntity>(
        Expression<Func<TPreviousEntity, object>> thenInclude);
    ISharedGenericRepository<T, TDto, TPostDto, TPutDto> Where(Expression<Func<T, bool>> predicate);
    ISharedGenericRepository<T, TDto, TPostDto, TPutDto> OrderBy<TKey>(Expression<Func<T, TKey>> keySelector);
    ISharedGenericRepository<T, TDto, TPostDto, TPutDto> OrderByDescending<TKey>(Expression<Func<T, TKey>> keySelector);
    Task<PagedResponse<List<TDto>>> GetAllAsyncWithPaging(int pageNumber, int pageSize, Uri baseUri);
    Task<List<TDto>> GetAllAsync();
    Task<TDto> GetByIdAsync(Guid id, params Expression<Func<T, object>>[] includes);
    Task<T> FirstOrDefaultAsync(Expression<Func<T, bool>> predicate);
    Task<T> AddAsync(TPostDto dto);
    Task<T> UpdateAsync(TPutDto dto);
    Task DeleteAsync(Guid id);
    Task RemoveAsync(Guid id);
}

