﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using AutoMapper;
using Haj.Domain;
using Haj.EntityFramework;
using Haj.Services;
using Haj.Wrappers;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query;

public class SharedGenericRepository<T, TDto , TPostDto , TPutDto > : ISharedGenericRepository<T, TDto, TPostDto, TPutDto>
    where T : class, new()
    where TPostDto : class
    where TPutDto : IHasId // Ensure TPutDto has an Id property
    where TDto : class, new() // Ensure TDto can be instantiated
{
    private readonly TenantDbContext _context;
    private IQueryable<T> _query;
    private Expression<Func<T, bool>> _wherePredicate;
    private readonly DbSet<T> _dbSet;
    private readonly IMapper _mapper;
    private readonly ICurrentUserService CurrentUser;


    public SharedGenericRepository(TenantDbContext context, IMapper mapper, ICurrentUserService currentUser)
    {
        _context = context;
        _dbSet = _context.Set<T>();
        _query = _dbSet;
        _mapper = mapper;
        CurrentUser = currentUser;
    }

    public ISharedGenericRepository<T, TDto, TPostDto, TPutDto> Include(params Expression<Func<T, object>>[] includes)
    {
        foreach (var include in includes)
        {
            _query = _query.Include(include);
        }
        return this;
    }

    public ISharedGenericRepository<T, TDto, TPostDto, TPutDto> ThenInclude<TPreviousEntity>(
    Expression<Func<TPreviousEntity, object>> thenInclude)
    {
        // Cast to the specific includable query type
        if (_query is IIncludableQueryable<T, TPreviousEntity> includableQuery)
        {
            // Call ThenInclude with the right parameters
            _query = includableQuery.ThenInclude(thenInclude);
        }
        return this;
    }

    public ISharedGenericRepository<T, TDto, TPostDto, TPutDto> Where(Expression<Func<T, bool>> predicate)
    {
        _query = _query.Where(predicate);
        return this;
    }

    public async Task<List<TDto>> GetAllAsync()
    {
        var isDeletedProperty = typeof(T).GetProperty("IsDeleted");
        if (isDeletedProperty != null)
        {
            _query = _query.Where(e => EF.Property<bool>(e, "IsDeleted") == false);
        }
            
        var totalRecords = await _query.CountAsync();

        var pagedData = await _query.ToListAsync();

        var dtoList = pagedData.Select(entity => MapToDto(entity)).ToList();
        return dtoList;
    }
    public ISharedGenericRepository<T, TDto, TPostDto, TPutDto> OrderBy<TKey>(Expression<Func<T, TKey>> keySelector)
    {
        _query = _query.OrderBy(keySelector);
        return this;
    }

    public ISharedGenericRepository<T, TDto, TPostDto, TPutDto> OrderByDescending<TKey>(Expression<Func<T, TKey>> keySelector)
    {
        _query = _query.OrderByDescending(keySelector);
        return this;
    }
    public async Task<PagedResponse<List<TDto>>> GetAllAsyncWithPaging(int pageNumber, int pageSize, Uri baseUri)
    {
        var isDeletedProperty = typeof(T).GetProperty("IsDeleted");
        if (isDeletedProperty != null)
        {
            // Apply the condition to filter by IsDeleted if the property exists
            _query = _query.Where(e => EF.Property<bool>(e, "IsDeleted") == false);
        }

        if (typeof(T).GetProperty("CreateTimeStamp") != null)
        {
            _query = _query.OrderByDescending(e => EF.Property<DateTime>(e, "CreateTimeStamp"));
        }
        var totalRecords = await _query.CountAsync();

        var pagedData = await _query.Skip((pageNumber - 1) * pageSize)
                                    .Take(pageSize)
                                    .ToListAsync();

        var dtoList = pagedData.Select(entity => MapToDto(entity)).ToList();

        return CreatePagedResponse(dtoList, pageNumber, pageSize, totalRecords, baseUri);
    }

    public async Task<TDto> GetByIdAsync(Guid id, params Expression<Func<T, object>>[] includes)
    {
        IQueryable<T> query = _query;
        if (typeof(AuditableEntity).IsAssignableFrom(typeof(T)))
        {
            query = query.Include(nameof(AuditableEntity.CreateUser))
                         .Include(nameof(AuditableEntity.UpdateUser))
                         .Include(nameof(AuditableEntity.DeleteUser))
                         .Include(nameof(AuditableEntity.CreateSite))
                         .Include(nameof(AuditableEntity.UpdateSite))
                         .Include(nameof(AuditableEntity.DeleteSite));
        }
       

        foreach (var include in includes)
        {
            query = query.Include(include);
        }

        var entity = await query.FirstOrDefaultAsync(e => EF.Property<Guid>(e, "Id") == id);
        return MapToDto(entity);
    }

    public async Task<T> FirstOrDefaultAsync(Expression<Func<T, bool>> predicate)
    {
        return await _query.FirstOrDefaultAsync(predicate);
    }

    public async Task<T> AddAsync(TPostDto dto)
    {
        Guid FromstatusIdValue = await _context.HajFormStatus.Where(x => x.Name == "New").Select(x => x.Id).FirstOrDefaultAsync();
        var entity = new T();
        var idProperty = typeof(T).GetProperty("Id");
        if (idProperty != null && idProperty.PropertyType == typeof(Guid))
        {
            idProperty.SetValue(entity, Guid.NewGuid());
        }

        var activeProperty = typeof(T).GetProperty("Active");
        if (activeProperty != null && activeProperty.PropertyType == typeof(bool))
        {
            activeProperty.SetValue(entity, true);
        }

        var isDeletedProperty = typeof(T).GetProperty("IsDeleted");
        if (isDeletedProperty != null && isDeletedProperty.PropertyType == typeof(bool))
        {
            isDeletedProperty.SetValue(entity, false);
        }
        var CreatUseridProperty = typeof(T).GetProperty("CreateUserID");
        if (CreatUseridProperty != null && CreatUseridProperty.PropertyType == typeof(Guid?))
        {
            CreatUseridProperty.SetValue(entity, new Guid(CurrentUser.GetUserID()));
        }

        var CreateTimeStampProperty = typeof(T).GetProperty("CreateTimeStamp");
        if (CreateTimeStampProperty != null && CreateTimeStampProperty.PropertyType == typeof(DateTime?))
        {
            CreateTimeStampProperty.SetValue(entity, DateTime.Now);
        }

        var CreatSiteidProperty = typeof(T).GetProperty("CreateSiteID");
        if (CreatSiteidProperty != null && CreatSiteidProperty.PropertyType == typeof(Guid?))
        {
            CreatSiteidProperty.SetValue(entity, new Guid(CurrentUser.GetSiteID()));
        }
       
        var FormStatusIdProperty = typeof(T).GetProperty("FormStatusId");
        if (FormStatusIdProperty != null && FormStatusIdProperty.PropertyType == typeof(Guid))
        {
            FormStatusIdProperty.SetValue(entity, FromstatusIdValue);
        }
        if (FormStatusIdProperty != null && FormStatusIdProperty.PropertyType == typeof(Guid?))
        {
            FormStatusIdProperty.SetValue(entity, FromstatusIdValue);
        }
        MapPostDtoToEntity(dto, entity);
        await _context.Set<T>().AddAsync(entity);
        await _context.SaveChangesAsync();
        return entity;
    }

    public async Task<T> UpdateAsync(TPutDto dto)
    {
        var entity = await _context.Set<T>().FindAsync(dto.Id);
        if (entity != null)
        {
            var UpdateUseridProperty = typeof(T).GetProperty("UpdateUserID");
            if (UpdateUseridProperty != null && UpdateUseridProperty.PropertyType == typeof(Guid?))
            {
                UpdateUseridProperty.SetValue(entity, new Guid(CurrentUser.GetUserID()));
            }
            var UpDateTimeStampProperty = typeof(T).GetProperty("UpDateTimeStamp");
            if (UpDateTimeStampProperty != null && UpDateTimeStampProperty.PropertyType == typeof(DateTime?))
            {
                UpDateTimeStampProperty.SetValue(entity, DateTime.Now);
            }
            var UpdateSiteidProperty = typeof(T).GetProperty("UpdateSiteID");
            if (UpdateSiteidProperty != null && UpdateSiteidProperty.PropertyType == typeof(Guid?))
            {
                UpdateSiteidProperty.SetValue(entity, new Guid(CurrentUser.GetSiteID()));
            }
            MapPutDtoToEntity(dto, entity);
            _context.Set<T>().Update(entity);
            await _context.SaveChangesAsync();
        }
        return entity;
    }

    public async Task DeleteAsync(Guid id)
    {
        var entity = await _dbSet.FindAsync(id);
        if (entity == null)
        {
            throw new Exception("Entity not found");
        }

        var isDeletedProperty = typeof(T).GetProperty("IsDeleted");
        if (isDeletedProperty != null && isDeletedProperty.PropertyType == typeof(bool))
        {
            isDeletedProperty.SetValue(entity, true); // Mark as deleted
        }

        var activeProperty = typeof(T).GetProperty("Active");
        if (activeProperty != null && activeProperty.PropertyType == typeof(bool))
        {
            activeProperty.SetValue(entity, false); // Mark as deleted (set Active to false)
        }
        var DeleteUseridProperty = typeof(T).GetProperty("DeleteUserID");
        if (DeleteUseridProperty != null && DeleteUseridProperty.PropertyType == typeof(Guid?))
        {
            DeleteUseridProperty.SetValue(entity, new Guid(CurrentUser.GetUserID()));
        }
        var DeleteTimeStampProperty = typeof(T).GetProperty("DeleteTimeStamp");
        if (DeleteTimeStampProperty != null && DeleteTimeStampProperty.PropertyType == typeof(DateTime?))
        {
            DeleteTimeStampProperty.SetValue(entity, DateTime.Now);
        }
        var DeleteSiteidProperty = typeof(T).GetProperty("DeleteSiteID");
        if (DeleteSiteidProperty != null && DeleteSiteidProperty.PropertyType == typeof(Guid?))
        {
            DeleteSiteidProperty.SetValue(entity, new Guid(CurrentUser.GetSiteID()));
        }

        await _context.SaveChangesAsync();
    }
    public async Task RemoveAsync(Guid id)
    {
        var entity = await _dbSet.FindAsync(id);
        if (entity == null)
        {
            throw new Exception("Entity not found");
        }

        // Remove the entity from the context
        _dbSet.Remove(entity);

        // Save changes asynchronously to the database
        await _context.SaveChangesAsync();
    }

        private TDto MapToDto(T entity)
    {
        return _mapper.Map<TDto>(entity);
    }

    private void MapPostDtoToEntity(TPostDto dto, T entity)
    {
        _mapper.Map(dto, entity);
    }

    private void MapPutDtoToEntity(TPutDto dto, T entity)
    {
        _mapper.Map(dto, entity);
    }

    private PagedResponse<List<TDto>> CreatePagedResponse(List<TDto> pagedData, int pageNumber, int pageSize, int totalRecords, Uri baseUri)
    {
        var response = new PagedResponse<List<TDto>>(pagedData, pageNumber, pageSize);
        var totalPages = (double)totalRecords / pageSize;
        int roundedTotalPages = Convert.ToInt32(Math.Ceiling(totalPages));

        response.NextPage = pageNumber < roundedTotalPages
            ? new Uri($"{baseUri}?pageNumber={pageNumber + 1}&pageSize={pageSize}")
            : null;

        response.PreviousPage = pageNumber > 1
            ? new Uri($"{baseUri}?pageNumber={pageNumber - 1}&pageSize={pageSize}")
            : null;

        response.FirstPage = new Uri($"{baseUri}?pageNumber=1&pageSize={pageSize}");
        response.LastPage = roundedTotalPages > 0
            ? new Uri($"{baseUri}?pageNumber={roundedTotalPages}&pageSize={pageSize}")
            : null;

        response.TotalPages = roundedTotalPages;
        response.TotalRecords = totalRecords;

        return response;
    }
}

