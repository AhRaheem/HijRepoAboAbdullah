﻿using Haj.EntityFramework;
using Haj.Wrappers;
using Microsoft.EntityFrameworkCore;

namespace Haj.Domain.Shared.Services.Attachment
{
    public class GeneralAttachmentService
    {
        private readonly IWebHostEnvironment _env;
        private readonly TenantDbContext _context;

        public GeneralAttachmentService(IWebHostEnvironment env, TenantDbContext context)
        {
            _env = env;
            _context = context;
        }

        public async Task<ResponseID> UploadFile(string base64File, string fileName, string contentType,string Title, string Description, Guid entityId, Guid entityType)
        {
            if (string.IsNullOrEmpty(base64File))
                throw new Exception("Invalid file content.");

            // Decode the Base64 string to a byte array
            byte[] fileBytes = Convert.FromBase64String(base64File);

            // Create the directory if it doesn't exist
            string uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "uploads");
            //string uploadsFolder = Path.Combine(_env.WebRootPath, "uploads");
            if (!Directory.Exists(uploadsFolder))
                Directory.CreateDirectory(uploadsFolder);

            // Create a unique file name
            string uniqueFileName = $"{Guid.NewGuid()}_{fileName}";
            string filePath = Path.Combine(uploadsFolder, uniqueFileName);

            // Save the file to the server
            await File.WriteAllBytesAsync(filePath, fileBytes);

            // Create a new attachment record
            var attachment = new HajGeneralAttachment
            {
                FileName = fileName,
                FilePath = filePath,
                ContentType = contentType,
                FileSize = fileBytes.Length,
                RelatedEntityId = entityId,
                FormTypeId = entityType,
                Title=Title,
                Description=Description,
            };

            // Save to the database
            _context.HajGeneralAttachment.Add(attachment);
            await _context.SaveChangesAsync();

            return new ResponseID
            {
                ID = attachment.Id,
                Succeeded = true,
                Code = 200,
                Message = "تم التسجيل بنجاح "

            };
        }

        public async Task<HajGeneralAttachment> GetAttachment(Guid id)
        {
            return await _context.HajGeneralAttachment.FindAsync(id);
        }
        public async Task<List<HajGeneralAttachment>> GetAttachmentsByRelatedFormIdAndType(Guid relatedFormId, Guid formTypeId)
        {
            var attachments = await _context.HajGeneralAttachment
                .Where(a => a.RelatedEntityId == relatedFormId && a.FormTypeId == formTypeId)
                .ToListAsync();

            return attachments;
        }
    }
}
