﻿using Microsoft.AspNetCore.Identity.UI.Services;
using System.Net.Mail;
using System.Net;

namespace Haj.Services
{

    public class EmailSender : IEmailSender
    {
        private readonly IConfiguration _configuration;

        public EmailSender(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public async Task SendEmailAsync(string email, string subject, string htmlMessage)
        {
            // Use your SMTP client or any other email service provider here
            // Below is an example using SMTP
            var smtpClient = new SmtpClient(_configuration["Email:Host"])
            {
                Port = int.Parse(_configuration["Email:Port"]),
                Credentials = new NetworkCredential(
                    _configuration["Email:Username"], _configuration["Email:Password"]),
                EnableSsl = true,
            };

            await smtpClient.SendMailAsync(new MailMessage
            {
                From = new MailAddress(_configuration["Email:From"]),
                To = { email },
                Subject = subject,
                Body = htmlMessage,
                IsBodyHtml = true,
            });
        }
    }
}
