﻿namespace Haj.Domain.Shared.Services.Enum
{
    public class HajChequeStatus
    {
        public const string InProgress = "InProgress";
        public const string Paid = "Paid";
        public const string Returned = "Returned";
        public const string Cancelled = "Cancelled";

    }
}
