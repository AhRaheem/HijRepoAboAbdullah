﻿namespace Haj.Domain.Shared.Services.enums
{
    public class HajSiteType
    {
        public const string MainOrganization = "MainOrganization";
        public const string Inventory = "Inventory";
        public const string Branch = "Branch";
        public const string Department = "Department";
    }
}
