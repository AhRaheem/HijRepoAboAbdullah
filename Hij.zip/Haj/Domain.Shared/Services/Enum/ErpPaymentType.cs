﻿namespace Haj.Domain.Shared.Services.Enum
{
    public class HajPaymentType
    {
        public const string Cash = "Cash";
        public const string Visa = "Visa";
        public const string Check = "Check";
    }
}
