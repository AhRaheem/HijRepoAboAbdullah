﻿namespace Haj.Domain.Shared.Services.Enum
{
    public class HajPaymentTransactionType
    {
        public const string AddBySaleInvoice = "AddBySaleInvoice";
        public const string AddByReturnPurchaseInvoice = "AddByReturnPurchaseInvoice";
        public const string DiscountByPurchaseInvoice = "DiscountByPurchaseInvoice";
        public const string DiscountByReturnSaleInvoice = "DiscountByReturnSaleInvoice";
        public const string AddByContract = "AddByContract";
        public const string DiscountByContract = "DiscountByContract";
    }
}
