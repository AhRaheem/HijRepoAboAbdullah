﻿using Microsoft.AspNetCore.Authorization;

namespace Haj.Services.PermissionHandler
{
    public class PermissionRequirement : IAuthorizationRequirement
    {
        public string Permission { get; }

        public PermissionRequirement(string permission)
        {
            Permission = permission;
        }
    }
}
