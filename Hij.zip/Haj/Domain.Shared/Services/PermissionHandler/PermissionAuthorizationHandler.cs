﻿using Microsoft.AspNetCore.Authorization;

namespace Haj.Services.PermissionHandler
{
    public class PermissionAuthorizationHandler : AuthorizationHandler<PermissionRequirement>
    {
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, PermissionRequirement requirement)
        {
            // Check if the user's claims include the required permission
            var hasPermission = context.User.Claims
                .Any(c => c.Type == "Permission" && c.Value == requirement.Permission);

            if (hasPermission)
            {
                context.Succeed(requirement); // Permission granted
            }

            return Task.CompletedTask;
        }
    }
}
