﻿using Microsoft.AspNetCore.Authorization;
using System;


namespace Haj.Services.PermissionHandler
{

    [AttributeUsage(AttributeTargets.Method, AllowMultiple = true)]
    public class AuthorizePermissionAttribute : AuthorizeAttribute
    {
        public AuthorizePermissionAttribute(string permission) : base()
        {
            Policy = $"Permission:{permission}";
        }
    }

}
