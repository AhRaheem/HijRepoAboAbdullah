﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Options;

namespace Haj.Services.PermissionHandler
{
    public class PermissionAuthorizationPolicyProvider : DefaultAuthorizationPolicyProvider
    {
        public PermissionAuthorizationPolicyProvider(IOptions<AuthorizationOptions> options) : base(options)
        {
        }

        public override async Task<AuthorizationPolicy> GetPolicyAsync(string policyName)
        {
            if (policyName.StartsWith("Permission:"))
            {
                var policy = new AuthorizationPolicyBuilder()
                    .AddRequirements(new PermissionRequirement(policyName.Replace("Permission:", "")))
                    .Build();

                return await Task.FromResult(policy);
            }

            return await base.GetPolicyAsync(policyName);
        }
    }
}
