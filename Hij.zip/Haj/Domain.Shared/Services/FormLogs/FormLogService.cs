﻿using Haj.ApplicationContracts.EmptyDT;
using Haj.ApplicationContracts.HajFormLogsDT;
using Haj.EntityFramework;
using Haj.Services;

namespace Haj.Domain.Shared.Services.FormLogs
{
    public class FormLogService
    {
        public TenantDbContext Context { get; set; }
        private ICurrentUserService CurrentUser;

        public FormLogService(TenantDbContext context, ICurrentUserService currentUser)
        {
            Context = context;
            CurrentUser = currentUser;
        }



        public async Task AddFormLog(Guid relatedFormTypeId, Guid fromStatusId, Guid toStatusId ,Guid relatedFormId , string relatedFormNumber)
        {
            var LogPost = new HajFormLogs
            {
                RelatedFormNumber = relatedFormNumber,
                RelatedFormTypeId = relatedFormTypeId,
                FromStatusId = fromStatusId,
                ToStatusId = toStatusId,
                RelatedFormId = relatedFormId,
                UserWhoCreatedActionId = new Guid(CurrentUser.GetUserID())
            };
            await Context.HajFormLogs.AddAsync(LogPost);   
            await Context.SaveChangesAsync();
        }
    }
}
