﻿namespace Haj.Services
{
    public interface ISoftDelete
    {
        bool IsDeleted { get; set; }
    }
}
