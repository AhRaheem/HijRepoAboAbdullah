﻿namespace Haj.Services
{
    public interface IHasId
    {
       public Guid Id { get; set; } // or the appropriate type for your ID
    }
}
