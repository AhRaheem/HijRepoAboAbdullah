﻿namespace Haj.Domain.Shared.Services
{
    public interface ITenantServiceService
    {
        string GetConnectionString(string companyId);
    }
    public class TenantService : ITenantServiceService
    {
        private readonly IConfiguration _configuration;

        public TenantService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public string GetConnectionString(string companyId)
        {
            // Example: Retrieve the connection string dynamically
            return _configuration.GetConnectionString($"HajCompany_{companyId}")
                   ?? throw new Exception("Invalid Company ID or missing connection string.");
        }
    }
}