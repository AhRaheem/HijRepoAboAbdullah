﻿namespace Haj.Wrappers
{
    public class ResponseID
    {
        public Guid? ID { get; set; }
        public int? Code { get; set; }
        public bool? Succeeded { get; set; }
        public string? Message { get; set; }
    }
}
