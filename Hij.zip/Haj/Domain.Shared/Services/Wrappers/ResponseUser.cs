﻿

namespace Haj.Wrappers
{
    public class ResponseUser
    {
       // public LmsSystemUsers? user { get; set; }
        public int? Code { get; set; }
        public bool? Succeeded { get; set; }
        public string? Message { get; set; }
    }
}
