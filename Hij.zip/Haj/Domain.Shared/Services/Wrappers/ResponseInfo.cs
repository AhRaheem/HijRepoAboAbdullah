﻿using Haj.Wrappers;

namespace Haj
{
   
    public class ResponseInfo 
    {
        public ResponseToken Data { get; set; }
        public bool Succeeded { get; set; }
        public int Code { get; set; }
        public string Message { get; set; } 

    }
}
