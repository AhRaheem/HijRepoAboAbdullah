﻿namespace Haj.Wrappers
{
    public class UserTokenInfo
    {  
        public Guid? UserID { get; set; }
        public string? LoginName { get; set; }
        public string? UserType { get; set; } 
    }
}
