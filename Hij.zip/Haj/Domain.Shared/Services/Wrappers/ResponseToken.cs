﻿ 
namespace Haj.Wrappers
{
    public class ResponseToken
    {
        public string? AccessToken { get; set; }
        public string? RefreshToken { get; set; }
        public UserTokenInfo  UserInformation { get; set; } 
    }
}
