﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Haj.Domain
{
    public class HajBusinessPersonContactInfo
    {
        public Guid Id { get; set; } // معرف الاتصال (ID)
        public Guid? BusinessPersonId { get; set; } // معرف الموظف
        [ForeignKey("BusinessPersonId")]
        public virtual HajBusinessPerson BusinessPerson { get; set; } // كائن 
        public Guid? ContactTypeId { get; set; }
        [ForeignKey("ContactTypeId")]
        public HajContactType ContactType { get; set; } // نوع الاتصال (هاتف، بريد إلكتروني)
        public string ContactDetails { get; set; } // تفاصيل الاتصال
        public bool IsDeleted { get; set; }
        public bool Active { get; set; }
    }
}
