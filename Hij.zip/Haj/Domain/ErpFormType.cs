﻿using Haj.Domain;

namespace Haj.Domain
{
    public class HajFormType
    {
        public Guid Id { get; set; } 
        public string Code { get; set; }
        public string NameAr { get; set; }
        public bool HasPayment { get; set; }
        public bool? Active { get; set; }
    }
}
