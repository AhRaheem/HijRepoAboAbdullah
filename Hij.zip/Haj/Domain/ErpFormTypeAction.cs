﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Haj.Domain
{
    public class HajFormTypeAction
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public Guid? FormTypeID { get; set; }
        [ForeignKey("FormTypeID")]
        public HajFormType HajFormType { get; set; }
        [StringLength(100)] public string? Code { get; set; }
        [StringLength(100)] public string? NameAr { get; set; }
        [StringLength(100)] public string? NameEn { get; set; }
        [StringLength(100)] public string? FromStatusCode { get; set; }
        [StringLength(100)] public string? ToStatusCode { get; set; }

        public bool? DefaultAction { get; set; }
        public bool? Active { get; set; }
        public bool? IsDeleted { get; set; }

    }
}
