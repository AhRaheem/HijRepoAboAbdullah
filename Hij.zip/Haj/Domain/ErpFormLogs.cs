﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Haj.Domain
{
    public class HajFormLogs:AuditableEntity
    {
        public Guid RelatedFormTypeId { get; set; }
        [ForeignKey("RelatedFormTypeId")]
        public HajFormType FormType { get; set; }

        public Guid FromStatusId { get; set; }
        [ForeignKey("FromStatusId")]
        public HajFormStatus FromStatus { get; set; }

        public Guid ToStatusId { get; set; }
        [ForeignKey("ToStatusId")]
        public HajFormStatus ToStatus { get; set; }

        public Guid RelatedFormId { get; set; }
        public string RelatedFormNumber { get; set; }
        public Guid? UserWhoCreatedActionId { get; set; }
        [ForeignKey("UserWhoCreatedActionId")]
        public AspNetUsers UserWhoCreatedAction { get; set; }

    }
}
