﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Haj.Domain
{
    public class HajPermissions
    {
        [Key]
        public Guid Id { get; set; }
        public string? GroupName {  get; set; } 
        public string Name { get; set; }
        public string? ParentName { get; set; }
        public string Displayname { get; set; }
        public int Order { get; set; }
        public ICollection<HajPermissionGrant> PermissionGrant { get; set; }
    }
}
