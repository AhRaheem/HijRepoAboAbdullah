﻿
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Haj.Domain
{
    public class AuditableEntity
    {
        [Key]
        public Guid Id { get; set; }
        public Guid? CreateUserID { get; set; }
        [ForeignKey("CreateUserID")]
        public AspNetUsers CreateUser { get; set; }
        public Guid? UpdateUserID { get; set; }
        [ForeignKey("UpdateUserID")]
        public AspNetUsers UpdateUser { get; set; }
        public Guid? DeleteUserID { get; set; }
        [ForeignKey("DeleteUserID")]
        public AspNetUsers DeleteUser { get; set; }

        public Guid? CreateSiteID { get; set; }
        [ForeignKey(nameof(CreateSiteID))]
        public HajOrganizationStructure CreateSite { get; set; }
        public Guid? UpdateSiteID { get; set; }
        [ForeignKey(nameof(UpdateSiteID))]
        public HajOrganizationStructure UpdateSite { get; set; }
        public Guid? DeleteSiteID { get; set; }
        [ForeignKey(nameof(DeleteSiteID))]
        public HajOrganizationStructure DeleteSite { get; set; }
        public DateTime? CreateTimeStamp { get; set; }
        public DateTime? UpDateTimeStamp { get; set; }
        public DateTime? DeleteTimeStamp { get; set; }
        public bool Active { get; set; } = true;
        public bool IsDeleted { get; set; }
    }
}
