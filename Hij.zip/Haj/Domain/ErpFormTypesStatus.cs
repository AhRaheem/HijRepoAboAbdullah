﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Haj.Domain
{
    public class HajFormTypesStatus
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public Guid? FormTypeID { get; set; }
        [ForeignKey("FormTypeID")]
        public HajFormType HajFormType { get; set; }
        [StringLength(100)] public string? Name { get; set; }
        [StringLength(100)] public string? Code { get; set; }
        public bool? Closed { get; set; }
        public bool? Active { get; set; }
    }
}
