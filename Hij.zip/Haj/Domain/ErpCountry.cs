﻿using Haj.Domain;

namespace Haj.Domain
{
    public class HajCountry:BasicADEntity 
    {
        public string? CountryCode { get; set; }
    }
}
