﻿using Haj.Domain;

namespace Haj.Domain
{
    public class HajFormStatus : BasicADEntity
    {
        public static implicit operator Guid(HajFormStatus? v)
        {
            throw new NotImplementedException();
        }
    }
}
