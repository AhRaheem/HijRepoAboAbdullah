﻿using Haj.Domain;
using System.ComponentModel.DataAnnotations.Schema;

namespace Haj.Domain
{
    public class HajEmploye:AuditableEntity
    {
        public string Name { get; set; } // الاسم
        public DateTime? DateOfBirth { get; set; } // تاريخ الميلاد
        public DateTime? DateOfEmployment { get; set; } // تاريخ التوظيف        
        public decimal? Salary { get; set; } // الراتب
        public string? Email { get; set; } // Email Address
        public string? PhoneNumber { get; set; } // Phone Number
        public string? Address { get; set; } // Residential Address

        // Additional Properties
        public string? NationalID { get; set; } // National Identification Number
        public DateTime? DateOfTermination { get; set; } // Date of Termination (if applicable)
        public string? EmergencyContactName { get; set; } // Emergency Contact Name
        public string? EmergencyContactPhone { get; set; } // Emergency Contact Phone Number
        public string? BankAccountNumber { get; set; } // Bank Account Number for Salary Deposits
        public string? TaxID { get; set; } // Tax Identification Number

        // Performance Metrics
        public int? PerformanceRating { get; set; } // Overall Performance Rating (e.g., 1-5 scale)
        public int? YearsOfExperience { get; set; } // Total Years of Experience
        public int? AttendanceScore { get; set; }
        public Guid? EmployeUserId { get; set; }
        [ForeignKey("EmployeUserId")]
        public AspNetUsers EmployeUser { get; set; }
        public ICollection<HajEmployeContactInfo> EmployeContactInfo { get; set; }
    }
}
