﻿namespace Haj.Domain.Permission
{
    public class HajPermissionsData
    {
        public const string GroupName = "Haj";
        public const string BackofficeGroup = GroupName + ".backoffice";

        public static class SettingsPermissions
        {
            public const string SettingsNode = BackofficeGroup + ".settings";

            public const string LookupsNode = SettingsNode + ".lookups";

            public static class LookupsPermissions
            {
                public const string Create = LookupsNode + ".create";
                public const string Update = LookupsNode + ".update";
                public const string Remove = LookupsNode + ".remove";
            }

            public const string AccountNode = SettingsNode + ".Account";

            public const string UserNode = AccountNode + ".User";

            public static class UsHajermissions
            {
                public const string Create = UserNode + ".create";
                public const string Update = UserNode + ".update";
                public const string Remove = UserNode + ".remove";
            }

            public const string RoleNode = AccountNode + ".Role";
            public static class RolePermissions
            {
                public const string Create = RoleNode + ".create";
                public const string Update = RoleNode + ".update";
                public const string Remove = RoleNode + ".remove";
            }
          
            public const string RolePermissionNode = AccountNode + ".RolePermission";
            public static class RolePermissionPermissions
            {
                public const string Create = RolePermissionNode + ".create";
                public const string Update = RolePermissionNode + ".update";
                public const string Remove = RolePermissionNode + ".remove";
            }
           
            public const string UserRoleNode = AccountNode + ".UserRole";
            public static class UserRolePermissions
            {
                public const string Create = UserRoleNode + ".create";
                public const string Update = UserRoleNode + ".update";
                public const string Remove = UserRoleNode + ".remove";
            }
        }

        public static class InventoryManagementPermissions
        {
            public const string InventoryManagementNode = BackofficeGroup + ".InventoryManagement";
            public const string InventoryManagementSettingNode = InventoryManagementNode + ".Settings";
            public static class InventoryManagementSettingNodePermissions
            {
                public const string Class = InventoryManagementSettingNode + ".Class";
                public const string Color = InventoryManagementSettingNode + ".Color";
                public const string Product = InventoryManagementSettingNode + ".Product";
                public const string ProductType = InventoryManagementSettingNode + ".ProductType";
                public const string PurchaseCondition = InventoryManagementSettingNode + ".PurchaseCondition";
                public const string Size = InventoryManagementSettingNode + ".Size";
                public const string StorageLocation = InventoryManagementSettingNode + ".StorageLocation";
                public const string StorageLocationType = InventoryManagementSettingNode + ".StorageLocationType";
                public const string Tax = InventoryManagementSettingNode + ".Tax";
                public const string UnitOfIssue = InventoryManagementSettingNode + ".UnitOfIssue";
            }

            public const string InventoryManagementInvoiceNode = InventoryManagementNode + ".Invoices";
            public const string InventoryManagementContractsNode = InventoryManagementNode + ".Contracts";
            public const string InventoryManagementPaymentsNode = InventoryManagementNode + ".Payments";
            public const string InventoryManagementChequeTransactionNode = InventoryManagementNode + ".ChequeTransaction";
            public const string InventoryManagementWarehouseNode = InventoryManagementNode + ".Warehouse"; 


            public const string InvPurchaseInvoice = InventoryManagementInvoiceNode + ".InvPurchaseInvoice";

            public static class InvPurchaseInvoicePermissions
            {
                public const string Create = InvPurchaseInvoice + ".create";
                public const string Update = InvPurchaseInvoice + ".update";
                public const string Remove = InvPurchaseInvoice + ".remove";
            }

            public const string InvSaleInvoice = InventoryManagementInvoiceNode + ".InvSaleInvoice";

            public static class InvSaleInvoicePermissions
            {
                public const string Create = InvSaleInvoice + ".create";
                public const string Update = InvSaleInvoice + ".update";
                public const string Remove = InvSaleInvoice + ".remove";
            }

            public const string InvReturnSaleInvoice = InventoryManagementInvoiceNode + ".InvReturnSaleInvoice";

            public static class InvReturnSaleInvoicePermissions
            {
                public const string Create = InvReturnSaleInvoice + ".create";
                public const string Update = InvReturnSaleInvoice + ".update";
                public const string Remove = InvReturnSaleInvoice + ".remove";
            }


            public const string InvPayment = InventoryManagementPaymentsNode + ".InvPayment";

            public static class InvPaymentPermissions
            {
                public const string Create = InvPayment + ".create";
                public const string Update = InvPayment + ".update";
                public const string Remove = InvPayment + ".remove";
            }

            public const string InvChequeTransaction = InventoryManagementChequeTransactionNode + ".ChequeTransaction";

            public static class InvChequeTransactionPermissions
            {
                public const string Create = InvChequeTransaction + ".create";
                public const string Update = InvChequeTransaction + ".update";
                public const string Remove = InvChequeTransaction + ".remove";
            }

            public const string InvWarehouseTransaction = InventoryManagementWarehouseNode + ".InvWarehouseTransaction";

            public static class InvWarehouseTransactionPermissions
            {
                public const string Create = InvWarehouseTransaction + ".create";
                public const string Update = InvWarehouseTransaction + ".update";
                public const string Remove = InvWarehouseTransaction + ".remove";
            }

            public const string InvWarehouseTransfer = InventoryManagementWarehouseNode + ".InvWarehouseTransfer";

            public static class InvWarehouseTransfHajermissions
            {
                public const string Create = InvWarehouseTransfer + ".create";
                public const string Update = InvWarehouseTransfer + ".update";
                public const string Remove = InvWarehouseTransfer + ".remove";
            }

            public const string InvWarehouseProduct = InventoryManagementWarehouseNode + ".InvWarehouseProduct";

            public static class InvWarehouseProductPermissions
            {
                public const string Create = InvWarehouseProduct + ".create";
                public const string Update = InvWarehouseProduct + ".update";
                public const string Remove = InvWarehouseProduct + ".remove";
            }

            public const string InvReceiving = InventoryManagementWarehouseNode + ".InvReceiving";

            public static class InvReceivingPermissions
            {
                public const string Create = InvReceiving + ".create";
                public const string Update = InvReceiving + ".update";
                public const string Remove = InvReceiving + ".remove";
            }

            public const string InvReceivingCommittee = InventoryManagementWarehouseNode + ".InvReceivingCommittee";

            public static class InvReceivingCommitteePermissions
            {
                public const string Create = InvReceivingCommittee + ".create";
                public const string Update = InvReceivingCommittee + ".update";
                public const string Remove = InvReceivingCommittee + ".remove";
            }

            public const string InvStockTaking = InventoryManagementWarehouseNode + ".InvStockTaking";

            public static class InvStockTakingPermissions
            {
                public const string Create = InvStockTaking + ".create";
                public const string Update = InvStockTaking + ".update";
                public const string Remove = InvStockTaking + ".remove";
            }

            public const string InvPurchaseOrder = InventoryManagementInvoiceNode + ".InvPurchaseOrder";

            public static class InvPurchaseOrdHajermissions
            {
                public const string Create = InvPurchaseOrder + ".create";
                public const string Update = InvPurchaseOrder + ".update";
                public const string Remove = InvPurchaseOrder + ".remove";
            }

            public const string InvVendorPurchaseOrderReplay = InventoryManagementInvoiceNode + ".InvVendorPurchaseOrderReplay";

            public static class InvVendorPurchaseOrderReplayPermissions
            {
                public const string Create = InvVendorPurchaseOrderReplay + ".create";
                public const string Update = InvVendorPurchaseOrderReplay + ".update";
                public const string Remove = InvVendorPurchaseOrderReplay + ".remove";
            }

            public const string InvContract = InventoryManagementContractsNode + ".InvContract";

            public static class InvContractPermissions
            {
                public const string Create = InvContract + ".create";
                public const string Update = InvContract + ".update";
                public const string Remove = InvContract + ".remove";
            }

            public const string InvReturnPurchaseInvoice = InventoryManagementInvoiceNode + ".InvReturnPurchaseInvoice";

            public static class InvReturnPurchaseInvoicePermissions
            {
                public const string Create = InvReturnPurchaseInvoice + ".create";
                public const string Update = InvReturnPurchaseInvoice + ".update";
                public const string Remove = InvReturnPurchaseInvoice + ".remove";
            }
            public const string InvPurchaseDiscrepancy = InventoryManagementInvoiceNode + ".InvPurchaseDiscrepancy";

            public static class InvPurchaseDiscrepancyPermissions
            {
                public const string Create = InvPurchaseDiscrepancy + ".create";
                public const string Update = InvPurchaseDiscrepancy + ".update";
                public const string Remove = InvPurchaseDiscrepancy + ".remove";
            }

            public const string InvEmployeCustody = InventoryManagementWarehouseNode + ".InvEmployeCustody";

            public static class InvEmployeCustodyPermissions
            {
                public const string Create = InvEmployeCustody + ".create";
                public const string Update = InvEmployeCustody + ".update";
                public const string Remove = InvEmployeCustody + ".remove";
            }

            public const string InvSiteCustody = InventoryManagementWarehouseNode + ".InvSiteCustody";

            public static class InvSiteCustodyPermissions
            {
                public const string Create = InvSiteCustody + ".create";
                public const string Update = InvSiteCustody + ".update";
                public const string Remove = InvSiteCustody + ".remove";
            }
        }
    }
}


