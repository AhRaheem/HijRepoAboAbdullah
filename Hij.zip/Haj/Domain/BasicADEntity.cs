﻿namespace Haj.Domain
{
    public class BasicADEntity
    {
        public Guid Id { get; set; } 
        public string Name { get; set; } 
        public bool Active { get; set; }
        public bool IsDeleted { get; set; }

    }
}
