﻿
using System.ComponentModel.DataAnnotations.Schema;

namespace Haj.Domain
{
    public class HajEmployeContactInfo
    {
        public Guid Id { get; set; } // معرف الاتصال (ID)
        public Guid? EmployeId { get; set; } // معرف الموظف
        [ForeignKey("EmployeId")]
        public virtual HajEmploye HajEmploye { get; set; } // كائن 
        public Guid? ContactTypeId { get; set; }
        [ForeignKey("ContactTypeId")]
        public HajContactType ContactType { get; set; } // نوع الاتصال (هاتف، بريد إلكتروني)
        public string ContactDetails { get; set; }
        public bool IsDeleted { get; set; }
        public bool Active { get; set; }
    }
}
