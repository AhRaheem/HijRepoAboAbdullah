﻿using Haj.Domain.Permission;
using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace Haj.Domain
{
    public class HajPermissionGrant
    {
        [Key]
        public Guid Id { get; set; }
        public string RoleName { get; set; }
        public string PermissionName { get; set; }
    }
}
