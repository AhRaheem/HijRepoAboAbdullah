﻿using Haj.Domain;

namespace Haj.Domain
{
    public class HajCurrency:BasicADEntity
    {
    }
}
