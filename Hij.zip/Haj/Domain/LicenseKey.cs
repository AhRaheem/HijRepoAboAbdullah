﻿
using Haj.Domain;
using System.ComponentModel.DataAnnotations;

namespace BanhaExamSystem.Models.Entities.SysControl
{
    public class LicenseKey
    {
        public Guid Id { get; set; }
        [StringLength(1000)] public string? LicenseSerialKey { get; set; }
    }
}
