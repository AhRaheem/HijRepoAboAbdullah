﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations.Schema;

namespace Haj.Domain
{
    public class AspNetUsers : IdentityUser<Guid>
    {
        public string FirstName { get; set; }
        public string? VerificationCode { get; set; }
        public string LastName { get; set; }
        public string? Photo {  get; set; }
        public Guid? OwnerSiteId { get; set; }
        [ForeignKey("OwnerSiteId")]
        public HajOrganizationStructure HajOrganizationStructure { get; set; }
        public bool Active { get; set; }
        public bool IsDeleted { get; set; }
    }
}
