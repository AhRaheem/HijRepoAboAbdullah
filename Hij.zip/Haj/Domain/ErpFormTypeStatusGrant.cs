﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Haj.Domain
{
    public class HajFormTypeStatusGrant
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public string? RoleName { get; set; }
        public Guid? HajFormTypesStatusId { get; set; }
        [ForeignKey("HajFormTypesStatusId")]
        public HajFormTypesStatus HajFormTypesStatus { get; set; }
        public bool? Active { get; set; }
    }
}
