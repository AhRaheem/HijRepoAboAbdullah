﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Haj.Domain
{
    public class HajGeneralAttachment:AuditableEntity
    {
        public Guid RelatedEntityId { get; set; }
        public Guid FormTypeId { get; set; }
        [ForeignKey("FormTypeId")]
        public HajFormType FormType { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public string ContentType { get; set; }
        public long FileSize { get; set; }
        public string? Title { get; set; }
        public string? Description { get; set; }
        
    }
}
