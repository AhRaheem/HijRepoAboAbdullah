﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations.Schema;

namespace Haj.Domain
{
    public class HajFormTypeActionGrant
    {
        public Guid Id { get; set; }= Guid.NewGuid();
        public string? RoleName { get; set; }
        public Guid? FormTypeActionId { get; set; }
        [ForeignKey("FormTypeActionId")]
        public HajFormTypeAction HajFormTypeAction { get; set; }
        public bool? Active { get; set; }
    }
}
