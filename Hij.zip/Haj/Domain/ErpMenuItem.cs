﻿using Haj.Domain;
using System.ComponentModel.DataAnnotations.Schema;

namespace Haj.Domain
{
    public class HajMenuItem:BasicADEntity
    {
        public string? Url { get; set; }
        public string? Icon { get; set; }
        public int? Order { get; set; }
        public Guid? ParentId { get; set; }
        [ForeignKey("ParentId")]
        public HajMenuItem ParentMenuItem { get; set; }
        public ICollection<HajMenuItem> Children { get; set; } = new List<HajMenuItem>();
        public string? RequiredPermission { get; set; }  // Optional for role-based menus
    }
}
