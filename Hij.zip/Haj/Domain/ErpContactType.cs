﻿
namespace Haj.Domain
{
    public class HajContactType:BasicADEntity
    {
    }
}
