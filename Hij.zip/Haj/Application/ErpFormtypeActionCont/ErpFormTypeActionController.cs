﻿using Haj.Domain;
using Haj.ApplicationContracts.HajFormTypeActionDT;
using Haj.ApplicationContracts.EmptyDT;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Haj.EntityFramework;
using Haj.Domain.Shared.Services.CurrentUser;


namespace Haj.Application.HajFormtypeActionCont
{
    [Route("Haj/[controller]/[action]")]
    [ApiController]
    [Authorize]
    public class HajFormTypeActionController : ControllerBase
    {
        private readonly TenantDbContext _appDbContext;
        private readonly UserActionAndStatusService _UserActionAndStatusService;
        private readonly ISharedGenericRepository<HajFormTypeAction, HajFormTypeActionDto, EmptyPostDto, EmptyPutDto> _HajFormTypeActionRepository;
        public HajFormTypeActionController(TenantDbContext appDbContext, ISharedGenericRepository<HajFormTypeAction, HajFormTypeActionDto, EmptyPostDto, EmptyPutDto> HajFormTypeActionRepository, UserActionAndStatusService userActionAndStatusService)
        {
            _appDbContext = appDbContext;
            _HajFormTypeActionRepository = HajFormTypeActionRepository;
            _UserActionAndStatusService = userActionAndStatusService;
        }
        [HttpGet]
        public async Task<ActionResult<List<HajFormTypeActionDto>>> GetActions(string FormTypeCode , string FormStatus)
        {
            var FormType = _appDbContext.HajFormType.Where(x => x.Code == FormTypeCode).FirstOrDefault();
            var actionAndStatus =await _UserActionAndStatusService.GetUser();
            var allowAction = actionAndStatus.Actions.ToList();
            var response = await _HajFormTypeActionRepository.Where(x=>allowAction.Contains(x.Id)&& x.FormTypeID==FormType.Id && x.FromStatusCode==FormStatus).GetAllAsync();
            return Ok(response);
        }
    }
}
