﻿using Haj.ApplicationContracts.HajPermissions;
using Haj.Domain;
using Haj.Domain.Permission;
using Haj.EntityFramework;
using Haj.Services.Filters;
using Haj.Services.PermissionHandler;
using Haj.Wrappers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Haj.Application.HajUserRoleCont
{
    [ApiController]
    [Route("Haj/[controller]/[action]")]
    public class UserRoleController : ControllerBase
    {
        private readonly UserManager<AspNetUsers> _userManager;
        private readonly RoleManager<IdentityRole<Guid>> _roleManager;
        private readonly IConfiguration _configuration;
        public readonly TenantDbContext _context;

        public UserRoleController(UserManager<AspNetUsers> userManager, IConfiguration configuration, RoleManager<IdentityRole<Guid>> roleManager, TenantDbContext context)
        {
            _userManager = userManager;
            _configuration = configuration;
            _roleManager = roleManager;
            _context = context;
        }

        [HttpGet]
        public async Task <ActionResult> GetRolesByEnail(string email)
        {
            var user = await _userManager.FindByEmailAsync(email);
            var result = await _userManager.GetRolesAsync(user);
            return Ok(result);
        }


        [HttpGet]
        public async Task<ActionResult<PagedResponse<List<object>>>> GetUsersWithRoles([FromQuery] PaginationFilter filter)
        {
            var baseUri = new Uri($"{Request.Scheme}://{Request.Host}{Request.Path}");
            var totalRecords = _userManager.Users.Count();
            var totalPages = (int)Math.Ceiling((double)totalRecords / filter.PageSize);

            var users = _userManager.Users
                                    .Skip((filter.PageNumber - 1) * filter.PageSize)
                                    .Take(filter.PageSize)
                                    .ToList();

            var userRolesList = new List<object>();

            foreach (var user in users)
            {
                var roles = await _userManager.GetRolesAsync(user);
                userRolesList.Add(new
                {
                    UserEmail = user.Email,
                    Roles = roles
                });
            }

            var firstPage = new Uri($"{baseUri}?PageNumber=1&PageSize={filter.PageSize}");
            var lastPage = new Uri($"{baseUri}?PageNumber={totalPages}&PageSize={filter.PageSize}");
            var nextPage = filter.PageNumber < totalPages
                ? new Uri($"{baseUri}?PageNumber={filter.PageNumber + 1}&PageSize={filter.PageSize}")
                : null;
            var previousPage = filter.PageNumber > 1
                ? new Uri($"{baseUri}?PageNumber={filter.PageNumber - 1}&PageSize={filter.PageSize}")
                : null;

            var response = new PagedResponse<List<object>>(userRolesList, filter.PageNumber, filter.PageSize)
            {
                FirstPage = firstPage,
                LastPage = lastPage,
                TotalPages = totalPages,
                TotalRecords = totalRecords,
                NextPage = nextPage,
                PreviousPage = previousPage
            };

            return Ok(response);
        }

       // [Authorize("Permission:Haj.backoffice.settings.lookups.update")]
        [HttpPost]
        public async Task<IActionResult> AddUserToRole(string userEmail, string roleName)
        {
            var user = await _userManager.FindByEmailAsync(userEmail);
            if (user == null)
            {
                return NotFound(new { Message = "User not found" });
            }

            var roleExists = await _roleManager.RoleExistsAsync(roleName);
            if (!roleExists)
            {
                return BadRequest(new { Message = "Role does not exist" });
            }

            var result = await _userManager.AddToRoleAsync(user, roleName);
            if (!result.Succeeded)
            {
                return BadRequest(result.Errors);
            }

            return Ok(new { Message = "Role assigned to user successfully" });
        }

        [HttpPost]
        public async Task<IActionResult> RemoveRoleFromUser(string userEmail, string roleName)
        {
            var user = await _userManager.FindByEmailAsync(userEmail);
            if (user == null)
            {
                return NotFound(new { Message = "User not found" });
            }

            var roleExists = await _roleManager.RoleExistsAsync(roleName);
            if (!roleExists)
            {
                return BadRequest(new { Message = "Role does not exist" });
            }

            var result = await _userManager.RemoveFromRoleAsync(user, roleName);
            if (!result.Succeeded)
            {
                return BadRequest(result.Errors);
            }

            return Ok(new { Message = "Role Removed From user successfully" });
        }
       

    }
}
