﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Haj.Services.Filters;
using Haj.Wrappers;
using Haj.Domain;
using Haj.ApplicationContracts.AspIdentityRoleDT;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Haj.EntityFramework;

namespace Haj.Application.IdentityRoleCont
{
    [Route("Haj/[controller]/[action]")]
    [ApiController]
    [Authorize]
    public class HajIdentityRoleController : ControllerBase
    {
        private readonly ISharedGenericRepository<IdentityRole<Guid>, IdentityRoleDto, IdentityRolePost, IdentityRolePut> _IdentityRoleRepository;
        private readonly RoleManager<IdentityRole<Guid>> _roleManager;
        public readonly TenantDbContext _context;
        public HajIdentityRoleController(ISharedGenericRepository<IdentityRole<Guid>, IdentityRoleDto, IdentityRolePost, IdentityRolePut> IdentityRoleRepository, RoleManager<IdentityRole<Guid>> roleManager, TenantDbContext context)
        {
            _IdentityRoleRepository = IdentityRoleRepository;
            _roleManager = roleManager;
            _context = context;
        }
        // GET: api/<IdentityRoleController>
        [HttpGet]
        public async Task<ActionResult<PagedResponse<List<IdentityRoleDto>>>> GetAll([FromQuery] PaginationFilter filter)
        {
            Uri baseUri = new Uri($"{Request.Scheme}://{Request.Host}{Request.Path}");
            var response = await _IdentityRoleRepository.GetAllAsyncWithPaging(filter.PageNumber, filter.PageSize, baseUri);
            return Ok(response);
        }

        [HttpGet]
        public async Task<ActionResult> GetAllPermissionByRoleName(string roleName)
        {
            var roleExists = await _roleManager.RoleExistsAsync(roleName);
            if (!roleExists)
            {
                return BadRequest(new { Message = "Role does not exist" });
            }
            var PermissionList = await _context.HajPermissionGrant.Where(x => x.RoleName == roleName).ToListAsync();
            return Ok(PermissionList);
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<IdentityRoleDto>> GetById(Guid id)
        {
            var IdentityRole = await _IdentityRoleRepository.GetByIdAsync(id);
            if (IdentityRole == null)
            {
                return NotFound();
            }
            return Ok(IdentityRole);
        }

        [HttpPost]
        public async Task<ActionResult<ResponseID>> Post([FromBody] IdentityRolePost postdata)
        {
            var createdIdentityRole = await _IdentityRoleRepository.AddAsync(postdata);

            //return CreatedAtAction(nameof(GetIdentityRole), new { id = createdIdentityRole.Id }, createdIdentityRole);
            return new ResponseID
            {
                ID = createdIdentityRole.Id,
                Succeeded = true,
                Code = 200,
                Message = "تم التسجيل بنجاح "

            };
        }

        [HttpPut()]
        public async Task<ActionResult> Put([FromBody] IdentityRolePut putData)
        {
            await _IdentityRoleRepository.UpdateAsync(putData);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(Guid id)
        {
            var roleExists = await _IdentityRoleRepository.GetByIdAsync(id);
            var PermissionList = await _context.HajPermissionGrant.Where(x => x.RoleName == roleExists.Name).ToListAsync();
            foreach (var item in PermissionList)
            {
                 _context.HajPermissionGrant.Remove(item);
                await _context.SaveChangesAsync();
            }
            await _IdentityRoleRepository.RemoveAsync(id);
            return NoContent();
        }
    }
}