﻿using Haj.ApplicationContracts.EmptyDT;
using Haj.ApplicationContracts.HajCountryDT;
using Haj.Domain;
using Haj.Services.Filters;
using Haj.Wrappers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Haj.ApplicationContracts.HajMenuItemDT;
using static System.Runtime.InteropServices.JavaScript.JSType;
using Microsoft.AspNetCore.Identity;
using Haj.ApplicationContracts.HajCurrencyDT;
using Haj.Domain.Shared.Services.CurrentUser;
using Haj.Services;

namespace Haj.Application.MenuCont
{
    [Route("Haj/[controller]/[action]")]
    [ApiController]
    [Authorize]
    public class HajMenuController : ControllerBase
    {
        private readonly ISharedGenericRepository<HajMenuItem, HajMenuItemDto, EmptyPostDto, HajMenuItemPut> _HajMenuItemRepository;
        private readonly UserManager<AspNetUsers> _userManager;
        private UserActionAndStatusService _userActionAndStatus;
        public ICurrentUserService currentUser;

        public HajMenuController(ISharedGenericRepository<HajMenuItem, HajMenuItemDto, EmptyPostDto, HajMenuItemPut> HajMenuItemRepository, UserManager<AspNetUsers> userManager, UserActionAndStatusService userActionAndStatus, ICurrentUserService currentUser)
        {
            _HajMenuItemRepository = HajMenuItemRepository;
            _userManager = userManager;
            _userActionAndStatus = userActionAndStatus;
            this.currentUser = currentUser;
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<PagedResponse<List<HajMenuItemDto>>>> GetAll([FromQuery] PaginationFilter filter)
        {
            Uri baseUri = new Uri($"{Request.Scheme}://{Request.Host}{Request.Path}");
            var userId = currentUser.GetUserID();
            var user2 = await _userManager.FindByIdAsync(userId);

            // Fetch the user's permissions
            var permissions = await _userActionAndStatus.GetUsHajermissionsAsync(user2);

            var response = await _HajMenuItemRepository
               .Include(x => x.Children)
               .Include(x => x.ParentMenuItem)
               .Where(x => x.ParentId == null && x.IsDeleted==false)
               .OrderBy(x => x.Order).Where(x=>permissions.Contains(x.RequiredPermission))
               .GetAllAsyncWithPaging(filter.PageNumber, filter.PageSize, baseUri);

           


            foreach (var item in response.Data)
            {
                item.Children = item.Children
                    .Where(x=>x.IsDeleted==false && permissions.Contains(x.RequiredPermission))
                    .OrderBy(child => child.Order).ToList();
            }
            return Ok(response);
        }

        [HttpGet]
        public async Task<ActionResult<PagedResponse<List<HajMenuItemDto>>>> GetAllForUpdate([FromQuery] PaginationFilter filter)
        {
            Uri baseUri = new Uri($"{Request.Scheme}://{Request.Host}{Request.Path}");
            var response = await _HajMenuItemRepository.GetAllAsyncWithPaging(filter.PageNumber, filter.PageSize, baseUri);
            return Ok(response);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<HajMenuItemDto>> GetById(Guid id)
        {
            var HajMenu = await _HajMenuItemRepository.GetByIdAsync(id);
            if (HajMenu == null)
            {
                return NotFound();
            }
            return Ok(HajMenu);
        }

        [HttpPut()]
        public async Task<ActionResult> Put([FromBody] HajMenuItemPut putData)
        {
            await _HajMenuItemRepository.UpdateAsync(putData);
            return NoContent();
        }
    }
}
