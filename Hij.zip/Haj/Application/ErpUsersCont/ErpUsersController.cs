﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Haj.Services.Filters;
using Haj.Wrappers;
using Haj.Domain;
using Haj.ApplicationContracts.AspNetUsersDT;
using Haj.Domain;
using Microsoft.AspNetCore.Identity;

namespace Haj.Application.AspNetUsersCont
{
    [Route("Haj/[controller]/[action]")]
    [ApiController]
    [Authorize]
    public class AspNetUsersController : ControllerBase
    {
        private readonly UserManager<AspNetUsers> _userManager;
        private readonly ISharedGenericRepository<AspNetUsers, AspNetUsersDto, AspNetUsersPost, AspNetUsersPut> _AspNetUsersRepository;

        public AspNetUsersController(ISharedGenericRepository<AspNetUsers, AspNetUsersDto, AspNetUsersPost, AspNetUsersPut> AspNetUsersRepository, Microsoft.AspNetCore.Identity.UserManager<AspNetUsers> userManager)
        {
            _AspNetUsersRepository = AspNetUsersRepository;
            _userManager = userManager;
        }
        // GET: api/<AspNetUsersController>
        [HttpGet]
        public async Task<ActionResult<PagedResponse<List<AspNetUsersDto>>>> GetAll([FromQuery] PaginationFilter filter)
        {
            Uri baseUri = new Uri($"{Request.Scheme}://{Request.Host}{Request.Path}");
            var response = await _AspNetUsersRepository.Include(x=>x.HajOrganizationStructure).GetAllAsyncWithPaging(filter.PageNumber, filter.PageSize, baseUri);
            return Ok(response);
        }

        

        [HttpGet("{id}")]
        public async Task<ActionResult<AspNetUsersDto>> GetById(Guid id)
        {
            var AspNetUsers = await _AspNetUsersRepository
                .Include(x=>x.HajOrganizationStructure).GetByIdAsync(id);
            if (AspNetUsers == null)
            {
                return NotFound();
            }
            return Ok(AspNetUsers);
        }

        [HttpPost]
        public async Task<ActionResult<ResponseID>> Post([FromBody] AspNetUsersPost postdata)
        {
            if (postdata.Password == postdata.ConfirmPassword)
            {
                var user = new AspNetUsers
                {
                    FirstName = postdata.FirstName,
                    LastName = postdata.LastName,
                    Photo = postdata.Photo,
                    OwnerSiteId = postdata.OwnerSiteId,
                    UserName = postdata.UserName,
                    NormalizedUserName = postdata.NormalizedUserName,
                    Email = postdata.Email,
                    NormalizedEmail = postdata.NormalizedEmail,
                    EmailConfirmed = postdata.EmailConfirmed,
                    PhoneNumber = postdata.PhoneNumber,
                    PhoneNumberConfirmed = postdata.PhoneNumberConfirmed,
                };
                var result = await _userManager.CreateAsync(user, postdata.Password);
                if (result.Succeeded)
                {
                    return new ResponseID
                    {
                        ID = null,
                        Succeeded = result.Succeeded,
                        Code = 200,
                        Message = "تم التسجيل بنجاح "

                    };
                }
                else
                {
                    return new ResponseID
                    {
                        ID = null,
                        Succeeded = result.Succeeded,
                        Code = 400,
                        Message = result.ToString()

                    };
                }
                
            }
            return new ResponseID
            {
                ID = null,
                Succeeded = false,
                Code = 400,
                Message = "لم يتم التسجيل بنجاح "

            };

        }

        [HttpPut()]
        public async Task<ActionResult> Put([FromBody] AspNetUsersPut putData)
        {
            await _AspNetUsersRepository.UpdateAsync(putData);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(Guid id)
        {
            await _AspNetUsersRepository.DeleteAsync(id);
            return NoContent();
        }
    }
}