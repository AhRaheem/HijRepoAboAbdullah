﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Haj.Services.Filters;
using Haj.Wrappers;
using Haj.Domain;
using Haj.ApplicationContracts.HajCurrencyDT;
using Haj.Domain;

namespace Haj.Application.HajCurrencyCont
{
    [Route("Haj/[controller]/[action]")]
    [ApiController]
    [Authorize]
    public class HajCurrencyController : ControllerBase
    {
        private readonly ISharedGenericRepository<HajCurrency, HajCurrencyDto, HajCurrencyPost, HajCurrencyPut> _HajCurrencyRepository;

        public HajCurrencyController(ISharedGenericRepository<HajCurrency, HajCurrencyDto, HajCurrencyPost, HajCurrencyPut> HajCurrencyRepository)
        {
            _HajCurrencyRepository = HajCurrencyRepository;
        }
        // GET: api/<HajCurrencyController>
        [HttpGet]
        public async Task<ActionResult<PagedResponse<List<HajCurrencyDto>>>> GetAll([FromQuery] PaginationFilter filter)
        {
            Uri baseUri = new Uri($"{Request.Scheme}://{Request.Host}{Request.Path}");
            var response = await _HajCurrencyRepository.GetAllAsyncWithPaging(filter.PageNumber, filter.PageSize, baseUri);
            return Ok(response);
        }

       
        [HttpGet("{id}")]
        public async Task<ActionResult<HajCurrencyDto>> GetById(Guid id)
        {
            var HajCurrency = await _HajCurrencyRepository.GetByIdAsync(id);
            if (HajCurrency == null)
            {
                return NotFound();
            }
            return Ok(HajCurrency);
        }

        [HttpPost]
        public async Task<ActionResult<ResponseID>> Post([FromBody] HajCurrencyPost postdata)
        {
            var createdHajCurrency = await _HajCurrencyRepository.AddAsync(postdata);

            //return CreatedAtAction(nameof(GetHajCurrency), new { id = createdHajCurrency.Id }, createdHajCurrency);
            return new ResponseID
            {
                ID = createdHajCurrency.Id,
                Succeeded = true,
                Code = 200,
                Message = "تم التسجيل بنجاح "

            };
        }

        [HttpPut()]
        public async Task<ActionResult> Put([FromBody] HajCurrencyPut putData)
        {
            await _HajCurrencyRepository.UpdateAsync(putData);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(Guid id)
        {
            await _HajCurrencyRepository.DeleteAsync(id);
            return NoContent();
        }
    }
}