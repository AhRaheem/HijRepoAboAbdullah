﻿using Haj.Domain.Shared.Enums;
using Haj.Domain.Shared.Services.Enum;
using Haj.Domain.Shared.Services.enums;
using Haj.EntityFramework;
using Microsoft.AspNetCore.Mvc;

namespace Haj.Application
{
    [Route("Haj/[controller]/[action]")]
    [ApiController]
    public class ConstantController : ControllerBase
    {
        public TenantDbContext _Context;
        public ConstantController(TenantDbContext context)
        {
            _Context = context;
        }

        [HttpGet]
        public ActionResult GetSiteType()
        {
            var enumList = ConstantsHelper.GetConstants<HajSiteType>();
            return Ok(enumList);
        }

        [HttpGet]
        public ActionResult GetFormType()
        {
            var enumList = _Context.HajFormType
                        .Select(x => new { x.Code, x.NameAr })  
                        .ToList();

            return Ok(enumList);
        }


       

        [HttpGet]
        public ActionResult GetPaymentTransactionType()
        {
            var enumList = ConstantsHelper.GetConstants<HajPaymentTransactionType>();
            return Ok(enumList);
        }

        [HttpGet]
        public ActionResult GetPaymentType()
        {
            var enumList = ConstantsHelper.GetConstants<HajPaymentType>();
            return Ok(enumList);
        }

        [HttpGet]
        public ActionResult GetChequeStatus()
        {
            var enumList = ConstantsHelper.GetConstants<HajChequeStatus>();
            return Ok(enumList);
        }

    }
}
