﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Haj.Services.Filters;
using Haj.Wrappers;
using Haj.Domain;
using Haj.ApplicationContracts.HajOrganizationStructureDT;
using Haj.Domain;
using Haj.Domain;
using Haj.ApplicationContracts.HajMenuItemDT;
using Microsoft.AspNetCore.Identity;
using Haj.Domain.Shared.Services.enums;

namespace Haj.Application.HajOrganizationStructureCont
{
    [Route("Haj/[controller]/[action]")]
    [ApiController]
    [Authorize]
    public class HajOrganizationStructureController : ControllerBase
    {
        private readonly ISharedGenericRepository<HajOrganizationStructure, HajOrganizationStructureDto, HajOrganizationStructurePost, HajOrganizationStructurePut> _HajOrganizationStructureRepository;

        public HajOrganizationStructureController(ISharedGenericRepository<HajOrganizationStructure, HajOrganizationStructureDto, HajOrganizationStructurePost, HajOrganizationStructurePut> HajOrganizationStructureRepository)
        {
            _HajOrganizationStructureRepository = HajOrganizationStructureRepository;
        }
        // GET: api/<HajOrganizationStructureController>
        [HttpGet]
        public async Task<ActionResult<PagedResponse<List<HajOrganizationStructureDto>>>> GetAll([FromQuery] PaginationFilter filter)
        {
            Uri baseUri = new Uri($"{Request.Scheme}://{Request.Host}{Request.Path}");

            var response = await _HajOrganizationStructureRepository
               .Include(x => x.ParentHajOrganizationStructure)
               .OrderBy(x => x.Order)
               .GetAllAsyncWithPaging(filter.PageNumber, filter.PageSize, baseUri);

            foreach (var item in response.Data)
            {
                item.Children = item.Children.OrderBy(child => child.Order).ToList();
            }
            return Ok(response);
        }

        [HttpGet]
        public async Task<ActionResult<PagedResponse<List<HajOrganizationStructureRelationalDto>>>> GetAllRelational([FromQuery] PaginationFilter filter)
        {
            Uri baseUri = new Uri($"{Request.Scheme}://{Request.Host}{Request.Path}");

            var response = await _HajOrganizationStructureRepository
               .GetAllAsyncWithPaging(filter.PageNumber, filter.PageSize, baseUri);

            return Ok(response);
        }
        [HttpGet]
        public async Task<ActionResult<PagedResponse<List<HajOrganizationStructureDto>>>> GetAllBySiteType(string siteType ,[FromQuery] PaginationFilter filter)
        {
            Uri baseUri = new Uri($"{Request.Scheme}://{Request.Host}{Request.Path}");

            var response = await _HajOrganizationStructureRepository
               .Include(x => x.ParentHajOrganizationStructure).Where(x=>x.En_SiteType== siteType)
               .OrderBy(x => x.Order)
               .GetAllAsyncWithPaging(filter.PageNumber, filter.PageSize, baseUri);

            foreach (var item in response.Data)
            {
                item.Children = item.Children.OrderBy(child => child.Order).ToList();
            }
            return Ok(response);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<HajOrganizationStructureDto>> GetById(Guid id)
        {
            var HajOrganizationStructure = await _HajOrganizationStructureRepository
               .Include(x => x.Children)
               .Include(x => x.ParentHajOrganizationStructure)
               .GetByIdAsync(id);
            if (HajOrganizationStructure == null)
            {
                return NotFound();
            }
            return Ok(HajOrganizationStructure);
        }

        [HttpPost]
        public async Task<ActionResult<ResponseID>> Post([FromBody] HajOrganizationStructurePost postdata)
        {
            var createdHajOrganizationStructure = await _HajOrganizationStructureRepository.AddAsync(postdata);

            //return CreatedAtAction(nameof(GetHajOrganizationStructure), new { id = createdHajOrganizationStructure.Id }, createdHajOrganizationStructure);
            return new ResponseID
            {
                ID = createdHajOrganizationStructure.Id,
                Succeeded = true,
                Code = 200,
                Message = "تم التسجيل بنجاح "

            };
        }

        [HttpPut()]
        public async Task<ActionResult> Put([FromBody] HajOrganizationStructurePut putData)
        {
            await _HajOrganizationStructureRepository.UpdateAsync(putData);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(Guid id)
        {
            await _HajOrganizationStructureRepository.DeleteAsync(id);
            return NoContent();
        }
    }
}