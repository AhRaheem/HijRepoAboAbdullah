﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

using Haj.Services.Filters;
using Haj.Wrappers;
using Haj.Domain;
using Haj.Basic;
using Haj.Domain;
using Haj.ApplicationContracts.HajFormLogsDT;
using Haj.ApplicationContracts.EmptyDT;

namespace Haj.Application.HajFormLogsCont
{
    [Route("Haj/[controller]/[action]")]
    [ApiController]
    [Authorize]
    public class HajFormLogsController : ControllerBase
    {
        private readonly ISharedGenericRepository<HajFormLogs, HajFormLogsDto, HajFormLogsPost, EmptyPutDto> _HajFormLogsRepository;

        public HajFormLogsController(ISharedGenericRepository<HajFormLogs, HajFormLogsDto, HajFormLogsPost, EmptyPutDto> HajFormLogsRepository)
        {
            _HajFormLogsRepository = HajFormLogsRepository;
        }
        // GET: api/<HajFormLogsController>
        [HttpGet]
        public async Task<ActionResult<PagedResponse<List<HajFormLogsDto>>>> GetAll([FromQuery] PaginationFilter filter)
        {
            Uri baseUri = new Uri($"{Request.Scheme}://{Request.Host}{Request.Path}");
            var response = await _HajFormLogsRepository
                .Include(x=>x.FromStatus)
                .Include(x=>x.ToStatus)
                .Include(x=>x.FormType)
                .GetAllAsyncWithPaging(filter.PageNumber, filter.PageSize, baseUri);
            return Ok(response);
        }

        [HttpGet]
        public async Task<ActionResult<PagedResponse<List<HajFormLogsDto>>>> GetRelatedLog(Guid FormId,Guid FormTypeId,[FromQuery] PaginationFilter filter)
        {
            Uri baseUri = new Uri($"{Request.Scheme}://{Request.Host}{Request.Path}");
            var response = await _HajFormLogsRepository
                .Include(x => x.FromStatus)
                .Include(x => x.ToStatus)
                .Include(x => x.FormType)
                .Where(x=>x.RelatedFormId == FormId && x.RelatedFormTypeId == FormTypeId)
                .GetAllAsyncWithPaging(filter.PageNumber, filter.PageSize, baseUri);
            return Ok(response);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<HajFormLogsDto>> GetById(Guid id)
        {
            var HajFormLogs = await _HajFormLogsRepository
                .Include(x => x.FromStatus)
                .Include(x => x.ToStatus)
                .Include(x => x.FormType).GetByIdAsync(id);
            if (HajFormLogs == null)
            {
                return NotFound();
            }
            return Ok(HajFormLogs);
        }
    }
}