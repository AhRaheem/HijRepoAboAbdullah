﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Haj.Services.Filters;
using Haj.Wrappers;
using Haj.Domain;
using Haj.ApplicationContracts.HajEmployeDT;
using Haj.Domain;
using Haj.ApplicationContracts.HajEmployeContactInfoDT;
using Haj.ApplicationContracts.AspNetUsersDT;
using Haj.Domain;
using Microsoft.AspNetCore.Identity;
using Haj.EntityFramework;
using Microsoft.EntityFrameworkCore;

namespace Haj.Application.HajDepartmentCont
{
    [Route("Haj/[controller]/[action]")]
    [ApiController]
    [Authorize]
    public class HajEmployeController : ControllerBase
    {
        private readonly ISharedGenericRepository<HajEmploye, HajEmployeDto, HajEmployePost, HajEmployePut> _HajEmployeRepository;
        private readonly ISharedGenericRepository<HajEmployeContactInfo, HajEmployeContactInfoDto, HajEmployeContactInfoPost, HajEmployeContactInfoPut> _HajEmployeContactInfoRepository;
        private readonly UserManager<AspNetUsers> _userManager;
        private readonly ISharedGenericRepository<AspNetUsers, AspNetUsersDto, AspNetUsersPost, AspNetUsersPut> _AspNetUsersRepository;
        private TenantDbContext _Context;
        public HajEmployeController(ISharedGenericRepository<HajEmploye, HajEmployeDto, HajEmployePost, HajEmployePut> HajEmployeRepository,
            ISharedGenericRepository<HajEmployeContactInfo, HajEmployeContactInfoDto, HajEmployeContactInfoPost, HajEmployeContactInfoPut> HajEmployeContactInfoRepository,
            UserManager<AspNetUsers> userManager,
            TenantDbContext context,
            ISharedGenericRepository<AspNetUsers, AspNetUsersDto, AspNetUsersPost, AspNetUsersPut> aspNetUsersRepository)
        {
            _HajEmployeRepository = HajEmployeRepository;
            _HajEmployeContactInfoRepository = HajEmployeContactInfoRepository;
            _userManager = userManager;
            _Context = context;
            _AspNetUsersRepository = aspNetUsersRepository;
        }
        // GET: api/<HajEmployeController>
        [HttpGet]
        public async Task<ActionResult<PagedResponse<List<HajEmployeDto>>>> GetAll([FromQuery] PaginationFilter filter)
        {
            Uri baseUri = new Uri($"{Request.Scheme}://{Request.Host}{Request.Path}");
            var response = await _HajEmployeRepository
                .Include(x=>x.EmployeContactInfo)
                .GetAllAsyncWithPaging(filter.PageNumber, filter.PageSize, baseUri);
            return Ok(response);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<List<HajEmployeDto>>> GetAllCallInfo(Guid id , [FromQuery] PaginationFilter filter)
        {
            Uri baseUri = new Uri($"{Request.Scheme}://{Request.Host}{Request.Path}");
            var response = await _HajEmployeContactInfoRepository.Include(x=>x.ContactType).Where(x => x.EmployeId == id)
                .GetAllAsyncWithPaging(filter.PageNumber, filter.PageSize, baseUri);
            return Ok(response);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<HajEmployeDto>> GetById(Guid id)
        {
            var HajEmploye = await _HajEmployeRepository.GetByIdAsync(id);
            if (HajEmploye == null)
            {
                return NotFound();
            }
            return Ok(HajEmploye);
        }

        [HttpPost]
        public async Task<ActionResult<ResponseID>> Post([FromBody] HajEmployePost postdata)
        {
            var createdHajEmploye = await _HajEmployeRepository.AddAsync(postdata);

            //return CreatedAtAction(nameof(GetHajEmploye), new { id = createdHajEmploye.Id }, createdHajEmploye);
            return new ResponseID
            {
                ID = createdHajEmploye.Id,
                Succeeded = true,
                Code = 200,
                Message = "تم التسجيل بنجاح "

            };
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<AspNetUsersDto>> GetUserByEmployeId(Guid id)
        {
            var Hajuser = await _AspNetUsersRepository
                .Include(x=>x.HajOrganizationStructure)
                .GetByIdAsync(id);
            if (Hajuser == null)
            {
                return NotFound();
            }
            return Ok(Hajuser);
        }
        [HttpPost]
        public async Task<ActionResult<ResponseID>> PostUserToEmploye(Guid EmployeId,[FromBody] AspNetUsersPost postdata)
        {
            if (postdata.Password == postdata.ConfirmPassword)
            {
                var user = new AspNetUsers
                {
                    FirstName = postdata.FirstName,
                    LastName = postdata.LastName,
                    Photo = postdata.Photo,
                    OwnerSiteId = postdata.OwnerSiteId,
                    UserName = postdata.UserName,
                    NormalizedUserName = postdata.NormalizedUserName,
                    Email = postdata.Email,
                    NormalizedEmail = postdata.NormalizedEmail,
                    EmailConfirmed = postdata.EmailConfirmed,
                    PhoneNumber = postdata.PhoneNumber,
                    PhoneNumberConfirmed = postdata.PhoneNumberConfirmed,
                };
                var result = await _userManager.CreateAsync(user, postdata.Password);
                var GetUserData=await _userManager.FindByEmailAsync(postdata.Email);
                if (GetUserData != null)
                {
                    var employe = await _Context.HajEmploye.Where(x=>x.Id==EmployeId).FirstOrDefaultAsync();
                    if (employe != null) 
                    {
                        employe.EmployeUserId = GetUserData.Id;
                         _Context.HajEmploye.Update(employe);
                         await _Context.SaveChangesAsync();
                    }
                }
                if (result.Succeeded)
                {
                    return new ResponseID
                    {
                        ID = null,
                        Succeeded = result.Succeeded,
                        Code = 200,
                        Message = "تم التسجيل بنجاح "

                    };
                }
                else
                {
                    return new ResponseID
                    {
                        ID = null,
                        Succeeded = result.Succeeded,
                        Code = 400,
                        Message = result.ToString()

                    };
                }

            }
            return new ResponseID
            {
                ID = null,
                Succeeded = false,
                Code = 400,
                Message = "لم يتم التسجيل بنجاح "

            };
        }

        [HttpPut()]
        public async Task<ActionResult<ResponseID>> PuttUserToEmploye(AspNetUsersPut putData)
        {
            await _AspNetUsersRepository.UpdateAsync(putData);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteUserFromEmploye(Guid Userid)
        {
            await _AspNetUsersRepository.DeleteAsync(Userid);
            return NoContent();
        }

        [HttpPost]
        public async Task<ActionResult<ResponseID>> PostCallInfo([FromBody] HajEmployeContactInfoPost postdata)
        {
            var createdHajEmployecall = await _HajEmployeContactInfoRepository.AddAsync(postdata);

            //return CreatedAtAction(nameof(GetHajEmploye), new { id = createdHajEmploye.Id }, createdHajEmploye);
            return new ResponseID
            {
                ID = createdHajEmployecall.Id,
                Succeeded = true,
                Code = 200,
                Message = "تم التسجيل بنجاح "
            };
        }

        [HttpPut()]
        public async Task<ActionResult> Put([FromBody] HajEmployePut putData)
        {
            await _HajEmployeRepository.UpdateAsync(putData);
            return NoContent();
        }

        [HttpPut()]
        public async Task<ActionResult> PutCallInfo([FromBody] HajEmployeContactInfoPut putData)
        {
            await _HajEmployeContactInfoRepository.UpdateAsync(putData);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(Guid id)
        {
            await _HajEmployeRepository.DeleteAsync(id);
            var CallInfoList =await _HajEmployeContactInfoRepository.Where(x=>x.EmployeId==id).GetAllAsync();
            foreach (var item in CallInfoList)
            {
                await _HajEmployeContactInfoRepository.DeleteAsync(item.Id);
            }
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteCallInfo(Guid id)
        {
            await _HajEmployeContactInfoRepository.DeleteAsync(id);
            return NoContent();
        }
    }
}