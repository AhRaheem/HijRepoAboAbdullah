﻿
using Haj.Domain;
using Haj.ApplicationContracts.EmptyDT;
using Haj.ApplicationContracts.HajCountryDT;
using Haj.ApplicationContracts.HajEmployeDT;
using Haj.Services.Filters;
using Haj.Wrappers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Haj.Application.HajEmployeCont
{
    [Route("Haj/[controller]/[action]")]
    [ApiController]
    [Authorize]
    public class HajEmployeRelationalController : ControllerBase
    {
        private readonly ISharedGenericRepository<HajEmploye, HajEmployeRelationalDto, EmptyPostDto, EmptyPutDto> _HajEmployeRepository;

        public HajEmployeRelationalController(ISharedGenericRepository<HajEmploye, HajEmployeRelationalDto, EmptyPostDto, EmptyPutDto> HajEmployeRepository)
        {
            _HajEmployeRepository = HajEmployeRepository;
        }
        // GET: api/<HajEmployeController>
        [HttpGet]
        public async Task<ActionResult<PagedResponse<List<HajEmployeRelationalDto>>>> GetAll([FromQuery] PaginationFilter filter)
        {
            Uri baseUri = new Uri($"{Request.Scheme}://{Request.Host}{Request.Path}");
            var response = await _HajEmployeRepository.GetAllAsyncWithPaging(filter.PageNumber, filter.PageSize, baseUri);
            return Ok(response);
        }

       
    }
}
