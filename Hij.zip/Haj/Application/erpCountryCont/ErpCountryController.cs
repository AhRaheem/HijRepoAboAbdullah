﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

using Haj.Services.Filters;
using Haj.Wrappers;
using Haj.Domain;
using Haj.Basic;
using Haj.Domain;
using Haj.ApplicationContracts.HajCountryDT;

namespace Haj.Application.HajCountryCont
{
    [Route("Haj/[controller]/[action]")]
    [ApiController]
    [Authorize]
    public class HajCountryController : ControllerBase
    {
        private readonly ISharedGenericRepository<HajCountry, HajCountryDto, HajCountryPost, HajCountryPut> _HajCountryRepository;

        public HajCountryController(ISharedGenericRepository<HajCountry, HajCountryDto, HajCountryPost, HajCountryPut> HajCountryRepository)
        {
            _HajCountryRepository = HajCountryRepository;
        }
        // GET: api/<HajCountryController>
        [HttpGet]
        public async Task<ActionResult<PagedResponse<List<HajCountryDto>>>> GetAll([FromQuery] PaginationFilter filter)
        {
            Uri baseUri = new Uri($"{Request.Scheme}://{Request.Host}{Request.Path}");
            var response = await _HajCountryRepository.GetAllAsyncWithPaging(filter.PageNumber, filter.PageSize, baseUri);
            return Ok(response);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<HajCountryDto>> GetById(Guid id)
        {
            var HajCountry = await _HajCountryRepository.GetByIdAsync(id);
            if (HajCountry == null)
            {
                return NotFound();
            }
            return Ok(HajCountry);
        }

        [HttpPost]
        public async Task<ActionResult<ResponseID>> Post([FromBody] HajCountryPost postdata)
        {
            var createdHajCountry = await _HajCountryRepository.AddAsync(postdata);

            //return CreatedAtAction(nameof(GetHajCountry), new { id = createdHajCountry.Id }, createdHajCountry);
            return new ResponseID
            {
                ID = createdHajCountry.Id,
                Succeeded = true,
                Code = 200,
                Message = "تم التسجيل بنجاح "

            };
        }

        [HttpPut()]
        public async Task<ActionResult> Put([FromBody] HajCountryPut putData)
        {
            await _HajCountryRepository.UpdateAsync(putData);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(Guid id)
        {
            await _HajCountryRepository.DeleteAsync(id);
            return NoContent();
        }
    }
}