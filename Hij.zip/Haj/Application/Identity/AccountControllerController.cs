﻿using Haj.ApplicationContracts.RegisterDto;
using Haj.Domain;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using System.Security.Claims;
using Microsoft.AspNetCore.Identity.UI.Services;
using Microsoft.Extensions.Options;
using Haj.Services;
using System.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication.Cookies;
using Haj.Domain.Shared.Services.CurrentUser;
using Haj.EntityFramework;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Haj.Domain.Shared.Services;
using Microsoft.AspNetCore.Identity.Data;

namespace Haj.Application
{

    public class AccountController : ControllerBase
    {
        private readonly UserManager<AspNetUsers> _userManager;
        private readonly SignInManager<AspNetUsers> _signInManager;
        private readonly IConfiguration _configuration;
        public IEmailSender _emailSender;
        public ISmsSender _smsSender;
        public readonly TenantDbContext _context;
        public ICurrentUserService currentUser;
        public ITenantServiceService _tenantService;

        public AccountController(UserManager<AspNetUsers> userManager,
                                 SignInManager<AspNetUsers> signInManager,
                                 IConfiguration configuration,
                                 IEmailSender emailSender,
                                 ISmsSender smsSender,
                                 TenantDbContext context,
                                 ICurrentUserService currentUser,
                                 ITenantServiceService tenantService)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _configuration = configuration;
            _emailSender = emailSender;
            _smsSender = smsSender;
            _context = context;
            this.currentUser = currentUser;
            _tenantService = tenantService;
        }

        // Register API
        [HttpPost("Register")]
        public async Task<IActionResult> Register([FromBody] RegisterDto model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var user = new AspNetUsers { UserName = model.UserName, Email = model.Email, FirstName = model.FirstName, LastName = model.LastName };
            var result = await _userManager.CreateAsync(user, model.Password);

            if (result.Succeeded)
            {
                var emailConfirmationToken = await _userManager.GenerateEmailConfirmationTokenAsync(user);
                var emailConfirmationUrl = Url.Action("ConfirmEmail", "Account", new { userId = user.Id, token = emailConfirmationToken }, Request.Scheme);
             //   await _emailSender.SendEmailAsync(model.Email, "Confirm your email", $"Please confirm your email by clicking <a href='{emailConfirmationUrl}'>here</a>");

                // Generate phone confirmation token
                var phoneConfirmationToken = await _userManager.GenerateChangePhoneNumberTokenAsync(user, model.PhoneNumber);

                // Send confirmation SMS (you need to implement the SendSmsAsync method)
              // await _smsSender.SendSmsAsync(model.PhoneNumber, $"Your confirmation code is {phoneConfirmationToken}");

                return Ok(new { Message = "User registered successfully. Please confirm your email and phone number." });
            }

            return BadRequest(result.Errors);
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [HttpGet("ConfirmEmail")]
        public async Task<IActionResult> ConfirmEmail(string userId, string token)
        {
            var user = await _userManager.FindByIdAsync(userId);
            if (user == null)
            {
                return BadRequest("Invalid user ID.");
            }

            var result = await _userManager.ConfirmEmailAsync(user, token);

            if (result.Succeeded)
            {
                return Ok("Email confirmed successfully.");
            }

            return BadRequest("Error confirming email.");
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [HttpPost("ConfirmPhoneNumber")]
        public async Task<IActionResult> ConfirmPhoneNumber(string userId, string token, string phoneNumber)
        {
            var user = await _userManager.FindByIdAsync(userId);
            if (user == null)
            {
                return BadRequest("Invalid user ID.");
            }

            var result = await _userManager.ChangePhoneNumberAsync(user, phoneNumber, token);

            if (result.Succeeded)
            {
                return Ok("Phone number confirmed successfully.");
            }

            return BadRequest("Error confirming phone number.");
        }
        // Login API
        [HttpPost("Login")]
        public async Task<IActionResult> Login([FromBody] LoginDto request)
        {
            try
            {
                var connectionString = _tenantService.GetConnectionString(request.CompanyId);
                if (string.IsNullOrEmpty(connectionString))
                    return Unauthorized("Invalid Company ID");

                var optionsBuilder = new DbContextOptionsBuilder<TenantDbContext>();
                optionsBuilder.UseSqlServer(connectionString);

                using var dbContext = new TenantDbContext(optionsBuilder.Options);

                bool isEmail = request.Identifier.Contains("@");

                var user = await dbContext.Users
                    .FirstOrDefaultAsync(u => isEmail ? u.Email == request.Identifier : u.PhoneNumber == request.Identifier);

                if (user == null)
                    return Unauthorized("Invalid credentials");

                var result = await _signInManager.CheckPasswordSignInAsync(user, request.Password, false);
                if (!result.Succeeded)
                    return Unauthorized("Invalid credentials");

                var token = GenerateJwtToken(user, request.CompanyId);

                return Ok(new { Token = token, CompanyId = request.CompanyId });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred: {ex.Message}");
            }
        }

        public async Task<string> GenerateUniqueVerificationCode()
        {
            string verificationCode;
            bool isUnique = false;

            do
            {
                verificationCode = new Random().Next(100000, 999999).ToString(); // Generate a 6-digit code
                isUnique = !await _userManager.Users.AnyAsync(u => u.VerificationCode == verificationCode);
            }
            while (!isUnique);

            return verificationCode;
        }
        private async Task<string> GenerateJwtToken(AspNetUsers user, string companyId)
        {
            var roles = _userManager.GetRolesAsync(user).Result;
            var claims = new List<Claim>
    {
       new Claim(JwtRegisteredClaimNames.Jti, user.Id.ToString()),
       new Claim(JwtRegisteredClaimNames.Email, user.Email),
        new Claim("CompanyId", companyId) 
    };

            var jwtSettings = _configuration.GetSection("JwtSettings");
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSettings["Secret"]));
            foreach (var role in roles)
            {
                claims.Add(new Claim(ClaimTypes.Role, role));
            }

            // Add permissions claims
            var permissions = await GetUserPermissionsAsync(user);

            foreach (var permission in permissions)
            {
                // claims.Add(new Claim("Permission", permission));
            }

            var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: jwtSettings["Issuer"],
                audience: jwtSettings["Audience"],
                claims: claims,
                expires: DateTime.Now.AddMinutes(double.Parse(jwtSettings["TokenLifetime"])),
                signingCredentials: credentials
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
        public async Task<List<string>> GetPermissionAsync(AspNetUsers user)
        {
            // Get roles assigned to the user
            var roles = await _userManager.GetRolesAsync(user);
            var permissions = new List<string>();

            // Fetch permissions based on the roles
            foreach (var role in roles)
            {
                var rolePermissions = await _context.HajPermissionGrant
                    .Where(pg => pg.RoleName == role)
                    .Select(pg => pg.PermissionName)
                    .ToListAsync();

                permissions.AddRange(rolePermissions);
            }

            return permissions.Distinct().ToList(); // Return distinct permissions
        }

        [Authorize]
        [HttpGet("GetUser")]
        public async Task<CurrentUserData> GetUser()
        {
            var userid = currentUser.GetUserID();
            Guid? SiteId =Guid.Parse(currentUser.GetSiteID());
            var Site =await _context.HajOrganizationStructure.Include(x=>x.ParentHajOrganizationStructure).Where(x => x.Id == SiteId).FirstOrDefaultAsync();
            string ParSite=null;
            if(Site.ParentHajOrganizationStructure != null)
            {
                ParSite = Site.ParentHajOrganizationStructure.Name;
            }
            var user2 = await _userManager.FindByIdAsync(userid);
            var roles = await _userManager.GetRolesAsync(user2);
            List<string> roleList = roles.ToList();
            var usHajermission = await GetPermissionAsync(user2);
            List<Guid?> actions =await _context.HajFormTypeActionGrant.Where(x => roles.Contains(x.RoleName)).Select(x=>x.FormTypeActionId).ToListAsync();
            List<Guid?> status = await _context.HajFormTypeStatusGrant.Where(x => roles.Contains(x.RoleName)).Select(x => x.HajFormTypesStatusId).ToListAsync();
            CurrentUserData userData = new CurrentUserData
            {
                LoginName = user2.FirstName +" "+ user2.LastName,
                Email=user2.Email,
                Photo = user2.Photo,
                RoleName = roleList,
                SiteName=Site.Name,
                ParentSiteName= ParSite,
                permsiisons =usHajermission
            };
            return userData;
        }
        [HttpPost("Logout")]
        [Authorize] 
        public async Task<IActionResult> Logout()
        {
            // Clear the user's authentication session
            await HttpContext.SignOutAsync();

            // Optionally, clear cookies here
            Response.Cookies.Delete(CookieAuthenticationDefaults.AuthenticationScheme);

            return Ok(new { message = "Logged out successfully." });
        }
        public async Task<List<string>> GetUserPermissionsAsync(AspNetUsers user)
        {
            // Get roles assigned to the user
            var roles = await _userManager.GetRolesAsync(user);
            var permissions = new List<string>();

            // Fetch permissions based on the roles
            foreach (var role in roles)
            {
                var rolePermissions = await _context.HajPermissionGrant
                .Where(pg => pg.RoleName == role)
                .Select(pg => pg.PermissionName)
                .ToListAsync();

                permissions.AddRange(rolePermissions);
            }

            return permissions.Distinct().ToList(); // Return distinct permissions
        }

    }
}