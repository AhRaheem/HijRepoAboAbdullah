﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

using Haj.Services.Filters;
using Haj.Wrappers;
using Haj.Domain;
using Haj.Basic;


namespace Haj.Application.HajContactTypeCont
{
    [Route("Haj/[controller]/[action]")]
    [ApiController]
    [Authorize]
    public class HajContactTypeController : ControllerBase
    {
        private readonly ISharedGenericRepository<HajContactType, BasicADEntityDto, BasicADEntityPost, BasicADEntityPut> _HajContactTypeRepository;

        public HajContactTypeController(ISharedGenericRepository<HajContactType, BasicADEntityDto, BasicADEntityPost, BasicADEntityPut> HajContactTypeRepository)
        {
            _HajContactTypeRepository = HajContactTypeRepository;
        }
        // GET: api/<HajContactTypeController>
        
        [HttpGet]
        public async Task<ActionResult<PagedResponse<List<BasicADEntityDto>>>> GetAll([FromQuery] PaginationFilter filter)
        {
            Uri baseUri = new Uri($"{Request.Scheme}://{Request.Host}{Request.Path}");
            var response = await _HajContactTypeRepository.GetAllAsyncWithPaging(filter.PageNumber, filter.PageSize, baseUri);
            return Ok(response);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<BasicADEntityDto>> GetById(Guid id)
        {
            var HajContactType = await _HajContactTypeRepository.GetByIdAsync(id);
            if (HajContactType == null)
            {
                return NotFound();
            }
            return Ok(HajContactType);
        }

        [HttpPost]
        public async Task<ActionResult<ResponseID>> Post([FromBody] BasicADEntityPost postdata)
        {
            var createdHajContactType = await _HajContactTypeRepository.AddAsync(postdata);

            //return CreatedAtAction(nameof(GetHajContactType), new { id = createdHajContactType.Id }, createdHajContactType);
            return new ResponseID
            {
                ID = createdHajContactType.Id,
                Succeeded = true,
                Code = 200,
                Message = "تم التسجيل بنجاح "

            };
        }

        [HttpPut()]
        public async Task<ActionResult> Put([FromBody] BasicADEntityPut putData)
        {
            await _HajContactTypeRepository.UpdateAsync(putData);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(Guid id)
        {
            await _HajContactTypeRepository.DeleteAsync(id);
            return NoContent();
        }
    }
}