﻿using Haj.Domain;
using Haj.ApplicationContracts.EmptyDT;
using Haj.ApplicationContracts.HajBusinessPersonDT;
using Haj.Services.Filters;
using Haj.Wrappers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Haj.Application.HajBusinessPersonCont
{
    [Route("Haj/[controller]/[action]")]
    [ApiController]
    public class HajBusinessPersonRelationalController : ControllerBase
    {
        private readonly ISharedGenericRepository<HajBusinessPerson, HajBusinessPersonRelationalDto, EmptyPostDto, EmptyPutDto> _HajBusinessPersonRepository;

        public HajBusinessPersonRelationalController(ISharedGenericRepository<HajBusinessPerson, HajBusinessPersonRelationalDto, EmptyPostDto, EmptyPutDto> HajBusinessPersonRepository)
        {
            _HajBusinessPersonRepository = HajBusinessPersonRepository;
        }
        // GET: api/<HajBusinessPersonController>
        [HttpGet]
        public async Task<ActionResult<PagedResponse<List<HajBusinessPersonRelationalDto>>>> GetAllCustomer ([FromQuery] PaginationFilter filter)
        {
            Uri baseUri = new Uri($"{Request.Scheme}://{Request.Host}{Request.Path}");
            var response = await _HajBusinessPersonRepository.Where(x=>x.IsSupplier==false).GetAllAsyncWithPaging(filter.PageNumber, filter.PageSize, baseUri);
            return Ok(response);
        }

        [HttpGet]
        public async Task<ActionResult<PagedResponse<List<HajBusinessPersonRelationalDto>>>> GetAllSupplier([FromQuery] PaginationFilter filter)
        {
            Uri baseUri = new Uri($"{Request.Scheme}://{Request.Host}{Request.Path}");
            var response = await _HajBusinessPersonRepository.Where(x=>x.IsSupplier==true).GetAllAsyncWithPaging(filter.PageNumber, filter.PageSize, baseUri);
            return Ok(response);
        }
    }
}
