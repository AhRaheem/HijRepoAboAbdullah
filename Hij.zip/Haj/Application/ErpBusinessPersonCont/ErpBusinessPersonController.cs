﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Haj.Services.Filters;
using Haj.Wrappers;
using Haj.Domain;
using Haj.ApplicationContracts.HajBusinessPersonDT;
using Haj.ApplicationContracts.HajBusinessPersonContactInfoDT;

namespace Haj.Application.HajDepartmentCont
{
    [Route("Haj/[controller]/[action]")]
    [ApiController]
    [Authorize]
    public class HajBusinessPersonController : ControllerBase
    {
        private readonly ISharedGenericRepository<HajBusinessPerson, HajBusinessPersonDto, HajBusinessPersonPost, HajBusinessPersonPut> _HajBusinessPersonRepository;
        private readonly ISharedGenericRepository<HajBusinessPersonContactInfo, HajBusinessPersonContactInfoDto, HajBusinessPersonContactInfoPost, HajBusinessPersonContactInfoPut> _HajBusinessPersonContactInfoRepository;
       
        public HajBusinessPersonController(ISharedGenericRepository<HajBusinessPerson, HajBusinessPersonDto, HajBusinessPersonPost, HajBusinessPersonPut> HajBusinessPersonRepository,
            ISharedGenericRepository<HajBusinessPersonContactInfo, HajBusinessPersonContactInfoDto, HajBusinessPersonContactInfoPost, HajBusinessPersonContactInfoPut> HajBusinessPersonContactInfoRepository)
        {
            _HajBusinessPersonRepository = HajBusinessPersonRepository;
            _HajBusinessPersonContactInfoRepository = HajBusinessPersonContactInfoRepository;
        }
        // GET: api/<HajBusinessPersonController>
        [HttpGet]
        public async Task<ActionResult<PagedResponse<List<HajBusinessPersonDto>>>> GetAll([FromQuery] PaginationFilter filter)
        {
            Uri baseUri = new Uri($"{Request.Scheme}://{Request.Host}{Request.Path}");
            var response = await _HajBusinessPersonRepository
                .GetAllAsyncWithPaging(filter.PageNumber, filter.PageSize, baseUri);
            return Ok(response);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<List<HajBusinessPersonDto>>> GetAllCallInfo(Guid id, [FromQuery] PaginationFilter filter)
        {
            Uri baseUri = new Uri($"{Request.Scheme}://{Request.Host}{Request.Path}");
            var response = await _HajBusinessPersonContactInfoRepository.Include(x => x.ContactType).Where(x => x.BusinessPersonId == id)
                .GetAllAsyncWithPaging(filter.PageNumber, filter.PageSize, baseUri);
            return Ok(response);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<HajBusinessPersonDto>> GetById(Guid id)
        {
            var HajBusinessPerson = await _HajBusinessPersonRepository.GetByIdAsync(id);
            if (HajBusinessPerson == null)
            {
                return NotFound();
            }
            return Ok(HajBusinessPerson);
        }

        [HttpPost]
        public async Task<ActionResult<ResponseID>> Post([FromBody] HajBusinessPersonPost postdata)
        {
            var createdHajBusinessPerson = await _HajBusinessPersonRepository.AddAsync(postdata);
          
            return new ResponseID
            {
                ID = createdHajBusinessPerson.Id,
                Succeeded = true,
                Code = 200,
                Message = "تم التسجيل بنجاح "

            };
        }

        [HttpPost]
        public async Task<ActionResult<ResponseID>> PostCallInfo([FromBody] HajBusinessPersonContactInfoPost postdata)
        {
            var createdHajBusinessPersoncall = await _HajBusinessPersonContactInfoRepository.AddAsync(postdata);

            return new ResponseID
            {
                ID = createdHajBusinessPersoncall.Id,
                Succeeded = true,
                Code = 200,
                Message = "تم التسجيل بنجاح "
            };
        }

        [HttpPut()]
        public async Task<ActionResult> Put([FromBody] HajBusinessPersonPut putData)
        {
            await _HajBusinessPersonRepository.UpdateAsync(putData);
            return NoContent();
        }

        [HttpPut()]
        public async Task<ActionResult> PutCallInfo([FromBody] HajBusinessPersonContactInfoPut putData)
        {
            await _HajBusinessPersonContactInfoRepository.UpdateAsync(putData);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(Guid id)
        {
            await _HajBusinessPersonRepository.DeleteAsync(id);
            var CallInfoList = await _HajBusinessPersonContactInfoRepository.Where(x => x.BusinessPersonId == id).GetAllAsync();
            foreach (var item in CallInfoList)
            {
                await _HajBusinessPersonContactInfoRepository.DeleteAsync(item.Id);
            }
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteCallInfo(Guid id)
        {
            await _HajBusinessPersonContactInfoRepository.DeleteAsync(id);
            return NoContent();
        }
    }
}