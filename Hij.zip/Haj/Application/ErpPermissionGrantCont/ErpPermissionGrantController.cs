﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

using Haj.Services.Filters;
using Haj.Wrappers;
using Haj.Domain;
using Haj.Basic;
using Haj.Domain;
using Haj.ApplicationContracts.HajPermissions;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Haj.EntityFramework;
using Haj.ApplicationContracts.HajCountryDT;

namespace Haj.Application.HajPermissionGrantCont
{
    [Route("Haj/[controller]/[action]")]
    [ApiController]
    [Authorize]
    public class HajPermissionGrantController : ControllerBase
    {
        public readonly TenantDbContext _context;
        private readonly RoleManager<IdentityRole<Guid>> _roleManager;
        public HajPermissionGrantController(TenantDbContext context, RoleManager<IdentityRole<Guid>> roleManager)
        {
            _context = context;
            _roleManager = roleManager;
        }
       
        [HttpPost]
        public async Task<IActionResult> AddPermissionToRole(string roleName, List<string> Permissions)
        {
            var roleExists = await _roleManager.RoleExistsAsync(roleName);
            if (!roleExists)
            {
                return BadRequest(new { Message = "Role does not exist" });
            }
            foreach (var item in Permissions)
            {

                var PermExist = await _context.HajPermissions.Where(x => x.Name == item).FirstOrDefaultAsync();
                if (PermExist != null)
                {
                    var RolePermission = new HajPermissionGrant
                    {
                        PermissionName = PermExist.Name,
                        RoleName = roleName
                    };
                    await _context.HajPermissionGrant.AddAsync(RolePermission);
                }
            }
            await _context.SaveChangesAsync();

            return Ok(new { Message = "Permssions assigned to Role successfully" });
        }

        [HttpPost]
        public async Task<IActionResult> RemovePermissionFromRole(string roleName, List<string> permissions)
        {
            // Check if the role exists
            var roleExists = await _roleManager.RoleExistsAsync(roleName);
            if (!roleExists)
            {
                return BadRequest(new { Message = "Role does not exist" });
            }

            // Fetch all permissions that match the provided names
            var matchingPermissions = await _context.HajPermissions
                .Where(p => permissions.Contains(p.Name))
                .ToListAsync();

            if (!matchingPermissions.Any())
            {
                return BadRequest(new { Message = "No matching permissions found." });
            }

            var permissionNames = matchingPermissions.Select(p => p.Name).ToList();
            var rolePermissions = await _context.HajPermissionGrant
                .Where(rp => rp.RoleName == roleName && permissionNames.Contains(rp.PermissionName))
            .ToListAsync();

            if (rolePermissions.Any())
            {
                _context.HajPermissionGrant.RemoveRange(rolePermissions);
                await _context.SaveChangesAsync();

                return Ok(new { Message = "Permissions removed from Role successfully." });
            }

            return BadRequest(new { Message = "No matching role-permission relationships found." });
        }
        [HttpGet]
        public async Task<List<HajPermissionsDto>> GetPermissionsTreeAsync()
        {
            var allPermissions = await _context.HajPermissions.ToListAsync();
            return BuildTree(null, allPermissions);
        }

        private List<HajPermissionsDto> BuildTree(string? parentName, List<HajPermissions> allPermissions)
        {
            return allPermissions
                .Where(p => p.ParentName == parentName)
                .Select(p => new HajPermissionsDto
                {
                    Id= p.Id,
                    Name= p.Name,
                    Displayname = p.Displayname,
                    Order = p.Order,
                    Children = BuildTree(p.Name, allPermissions)
                })
                .OrderBy(x => x.Order).ToList();
        }
    }
}