﻿using Haj.ApplicationContracts.HajGeneralAttachmentDT;
using Haj.Domain.Shared.Services.Attachment;
using Haj.Wrappers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.IO.Compression;

namespace Haj.Application.HajGeneralAttachmentCont
{
    [Route("Haj/[controller]/[action]")]
    [ApiController]
    [Authorize]
    public class HajGeneralAttachmentController : ControllerBase
    {
        private readonly GeneralAttachmentService _attachmentService;

        public HajGeneralAttachmentController(GeneralAttachmentService attachmentService)
        {
            _attachmentService = attachmentService;
        }

        [HttpPost]
        public async Task<ActionResult<ResponseID>> UploadAttachment([FromBody] HajUploadGeneralAttachmentDto request)
        {
            if (string.IsNullOrEmpty(request.FileBase64))
                return BadRequest("File content is required");

            var attachment = await _attachmentService.UploadFile(request.FileBase64, request.FileName, request.ContentType,request.Title,request.Description, request.RelatedFormId, request.FormTypeId);

            return Ok(attachment);
        }

        [HttpGet]
        public async Task<IActionResult> DownloadAttachment(Guid id)
        {
            var attachment = await _attachmentService.GetAttachment(id);
            if (attachment == null) return NotFound();

            var fileStream = new FileStream(attachment.FilePath, FileMode.Open, FileAccess.Read);
            return File(fileStream, attachment.ContentType, attachment.FileName);
        }

        [HttpGet]
        public async Task<IActionResult> DownloadAllAttachmentAsZip(Guid relatedFormId, Guid formTypeId)
        {
            var attachments = await _attachmentService.GetAttachmentsByRelatedFormIdAndType(relatedFormId, formTypeId);

            if (attachments == null || !attachments.Any())
                return NotFound("No attachments found.");

            // If you want to return multiple files in a ZIP
            var zipFileName = "attachments.zip";
            var memoryStream = new MemoryStream();

            using (var archive = new ZipArchive(memoryStream, ZipArchiveMode.Create, true))
            {
                foreach (var attachment in attachments)
                {
                    if (System.IO.File.Exists(attachment.FilePath))
                    {
                        var fileBytes = await System.IO.File.ReadAllBytesAsync(attachment.FilePath);
                        var fileEntry = archive.CreateEntry(attachment.FileName);
                        using (var entryStream = fileEntry.Open())
                        {
                            await entryStream.WriteAsync(fileBytes, 0, fileBytes.Length);
                        }
                    }
                }
            }

            memoryStream.Seek(0, SeekOrigin.Begin); // Reset stream position for download
            return File(memoryStream, "application/zip", zipFileName);
        }

        [HttpGet]
        public async Task<IActionResult> GetRelatedAttachmentMetadata(Guid relatedFormId, Guid formTypeId)
        {
            var attachments = await _attachmentService.GetAttachmentsByRelatedFormIdAndType(relatedFormId, formTypeId);

            if (attachments == null || !attachments.Any())
                return NotFound("No attachments found.");

            // Process attachments and convert to Base64
            var attachmentMetadata = await Task.WhenAll(attachments.Select(async a =>
            {
                string base64Data = null;
                if (!string.IsNullOrEmpty(a.FilePath) && System.IO.File.Exists(a.FilePath))
                {
                    try
                    {
                        byte[] fileBytes = await System.IO.File.ReadAllBytesAsync(a.FilePath);
                        base64Data = Convert.ToBase64String(fileBytes);
                    }
                    catch (Exception ex)
                    {
                        // Log the error
                        Console.WriteLine($"Error reading file {a.FilePath}: {ex.Message}");
                    }
                }

                return new
                {
                    a.Id,
                    a.FileName,
                    a.ContentType,
                    a.Title,
                    a.Description,
                    Base64 = base64Data
                };
            }));

            return Ok(attachmentMetadata);
        }

    }
}
