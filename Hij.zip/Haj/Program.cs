
using Haj.Domain.Shared.Services.Attachment;
using Haj.Domain.Shared.Services.CurrentUser;
using Haj.Domain.Shared.Services.FormLogs;
using Haj.Domain;
using Haj.EntityFramework;
using Haj.Services.PermissionHandler;
using Haj.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.UI.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.Text;
using Haj.Domain.Shared.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddScoped<ITenantServiceService, TenantService>();

builder.Services.AddDbContext<TenantDbContext>((serviceProvider, options) =>
{
    var httpContextAccessor = serviceProvider.GetRequiredService<IHttpContextAccessor>();
    var tenantService = serviceProvider.GetRequiredService<ITenantServiceService>();

    string companyId = httpContextAccessor.HttpContext?.User?.FindFirst("companyId")?.Value ?? "2";
    var connectionString = tenantService.GetConnectionString(companyId);

    options.UseSqlServer(connectionString);
});
builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<TenantDbContext>();

builder.Services.AddIdentity<AspNetUsers, IdentityRole<Guid>>()
    .AddEntityFrameworkStores<TenantDbContext>()
    .AddDefaultTokenProviders();

builder.Services.AddAutoMapper(typeof(Program));
builder.Services.AddScoped(typeof(ISharedGenericRepository<,,,>), typeof(SharedGenericRepository<,,,>));
builder.Services.AddScoped<ICurrentUserService, CurrentUserService>();
builder.Services.AddScoped<FormLogService>();
builder.Services.AddScoped<UserActionAndStatusService>();


builder.Services.AddScoped<GeneralAttachmentService>();

builder.Services.AddScoped<DataSeeder>();
builder.Services.AddTransient<IEmailSender, EmailSender>();
builder.Services.AddTransient<ISmsSender, SmsSender>();

// Configure JWT Authentication
var jwtSettings = builder.Configuration.GetSection("JwtSettings");
var key = Encoding.UTF8.GetBytes(jwtSettings["Secret"]);

builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new SymmetricSecurityKey(key),
        ValidateIssuer = true,
        ValidateAudience = false,
        ValidIssuer = jwtSettings["Issuer"],
        ValidAudience = jwtSettings["Audience"],
        RequireExpirationTime = true,
        ValidateLifetime = true
    };
});

builder.Services.AddAuthorization(options =>
{
    // Dynamic permission policy registration
    options.AddPolicy("Permission", policy =>
    {
        policy.Requirements.Add(new PermissionRequirement("default"));
    });
});

builder.Services.AddSwaggerGen(option =>
{
    option.SwaggerDoc("v1", new OpenApiInfo { Title = "Shared Api", Version = "v1" });
    option.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        In = ParameterLocation.Header,
        Description = "Please enter a valid token",
        Name = "Authorization",
        Type = SecuritySchemeType.Http,
        BearerFormat = "JWT",
        Scheme = "Bearer"
    });
    option.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            new string[]{}
        }
    });
});

// Enable CORS policy
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowSpecificOrigin", policy =>
    {
        policy.SetIsOriginAllowed(origin =>
        {
            // Ensure we are allowing only specific origins (localhost and your ERP frontend URL)
            var uri = new Uri(origin);
            return uri.Host == "localhost" || uri.AbsoluteUri.StartsWith("http://erpfrontend.somee.com") || uri.AbsoluteUri.StartsWith("http://slashappsnet-002-site4.atempurl.com");
        })
        .AllowAnyHeader()          // Allow any headers
        .AllowAnyMethod()          // Allow any HTTP methods
        .AllowCredentials();       // Allow credentials such as cookies
    });
});

builder.Services.AddControllers();

builder.Services.AddSingleton<IAuthorizationPolicyProvider, PermissionAuthorizationPolicyProvider>();
builder.Services.AddSingleton<IAuthorizationHandler, PermissionAuthorizationHandler>();

var app = builder.Build();

// Seed roles and permissions
using (var scope = app.Services.CreateScope())
{
    var roleSeeder = scope.ServiceProvider.GetRequiredService<DataSeeder>();
    await roleSeeder.SeedRolesAndPermissionsAndUserAsync();
}



if (!app.Environment.IsDevelopment())
{
    app.UseHttpsRedirection();  // Use this only in production or staging
}

app.UseAuthentication();
app.UseAuthorization();
app.UseCors("AllowSpecificOrigin");

app.UseSwagger();
app.UseSwaggerUI(c =>
{
    c.DefaultModelsExpandDepth(-1); // Hide model schema in Swagger UI
});

app.MapControllers();

app.Run();
