﻿using Haj.Services;

namespace Haj.ApplicationContracts.AuditableEntityDT
{
    public class AuditableEntityPut:IHasId
    {
        public Guid Id { get; set; }
        public bool Active { get; set; }
    }
}
