﻿using Haj.ApplicationContracts.AspNetUsersDT;
using Haj.ApplicationContracts.HajOrganizationStructureDT;
using Haj.Domain;
using System.ComponentModel.DataAnnotations.Schema;

namespace Haj.ApplicationContracts.AuditableEntityDT
{
    public class AuditableEntityDto
    {
        public Guid Id { get; set; }

        public AspNetUsersRelationalDto CreateUser { get; set; }
        public AspNetUsersRelationalDto UpdateUser { get; set; }
        public AspNetUsersRelationalDto DeleteUser { get; set; }

        public HajOrganizationStructureRelationalDto CreateSite { get; set; }

        public HajOrganizationStructureRelationalDto UpdateSite { get; set; }

        public HajOrganizationStructureRelationalDto DeleteSite { get; set; }

        public DateTime? CreateTimeStamp { get; set; }
        public DateTime? UpDateTimeStamp { get; set; }
        public DateTime? DeleteTimeStamp { get; set; }
        public bool Active { get; set; } = true;
        public bool IsDeleted { get; set; }
    }
}
