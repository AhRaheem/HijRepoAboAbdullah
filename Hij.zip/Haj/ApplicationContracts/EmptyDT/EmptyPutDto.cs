﻿using Haj.Services;

namespace Haj.ApplicationContracts.EmptyDT
{
    public class EmptyPutDto:IHasId
    {
        public Guid Id { get; set; }
    }
}
