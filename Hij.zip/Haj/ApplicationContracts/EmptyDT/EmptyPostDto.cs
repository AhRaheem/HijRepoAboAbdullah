﻿namespace Haj.ApplicationContracts.EmptyDT
{
    public class EmptyPostDto
    {
    }
}
