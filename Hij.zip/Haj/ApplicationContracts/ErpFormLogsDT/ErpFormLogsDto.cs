﻿using Haj.ApplicationContracts.AuditableEntityDT;
using Haj.ApplicationContracts.HajFormStatusDT;
using Haj.Domain;
using System.ComponentModel.DataAnnotations.Schema;

namespace Haj.ApplicationContracts.HajFormLogsDT
{
    public class HajFormLogsDto:AuditableEntityDto
    {
        public HajFormType FormType { get; set; }
        public HajFormStatusDto FromStatus { get; set; }
        public HajFormStatusDto ToStatus { get; set; }
        public Guid RelatedFormId { get; set; }
        public string FormNumber { get; set; }
    }
}
