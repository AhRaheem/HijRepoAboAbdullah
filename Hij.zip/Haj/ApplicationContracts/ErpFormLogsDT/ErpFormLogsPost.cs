﻿using Haj.Domain;
using System.ComponentModel.DataAnnotations.Schema;

namespace Haj.ApplicationContracts.HajFormLogsDT
{
    public class HajFormLogsPost
    {
        public Guid RelatedFormTypeId { get; set; }
        public Guid FromStatusId { get; set; }
        public Guid ToStatusId { get; set; }
        public Guid RelatedFormId { get; set; }
        public string FormNumber { get; set; }
    }
}
