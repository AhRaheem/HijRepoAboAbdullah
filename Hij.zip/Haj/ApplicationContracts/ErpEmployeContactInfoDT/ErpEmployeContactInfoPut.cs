﻿using Haj.Domain;
using Haj.Services;

namespace Haj.ApplicationContracts.HajEmployeContactInfoDT
{
    public class HajEmployeContactInfoPut:IHasId
    {
        public Guid Id { get; set; } 
        public Guid? EmployeId { get; set; }
        public Guid? ContactTypeId { get; set; }
        public string ContactDetails { get; set; }
        public bool active { get; set; }
    }
}
