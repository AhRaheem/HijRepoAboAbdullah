﻿using Haj.Domain;
using System.ComponentModel.DataAnnotations.Schema;

namespace Haj.ApplicationContracts.HajEmployeContactInfoDT
{
    public class HajEmployeContactInfoDto
    {
        public Guid Id { get; set; }
        public Guid? EmployeId { get; set; } 
        public Guid? ContactTypeId { get; set; }
        public HajContactType ContactType { get; set; } 
        public string ContactDetails { get; set; }
        public bool Active { get; set; }
    }
}
