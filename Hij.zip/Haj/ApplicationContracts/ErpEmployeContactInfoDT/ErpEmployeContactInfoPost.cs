﻿using Haj.Domain;

namespace Haj.ApplicationContracts.HajEmployeContactInfoDT
{
    public class HajEmployeContactInfoPost
    {
        public Guid? EmployeId { get; set; } // معرف الموظف
        public Guid? ContactTypeId { get; set; }
        public string ContactDetails { get; set; } // تفاصيل الاتصال
    }
}
