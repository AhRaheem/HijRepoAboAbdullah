﻿using Haj.ApplicationContracts.AuditableEntityDT;

namespace Haj.ApplicationContracts.HajEmployeDT
{
    public class HajEmployeRelationalDto
    {
        public Guid Id { get; set; }
        public string Name { get; set; } // الاسم
    }
}
