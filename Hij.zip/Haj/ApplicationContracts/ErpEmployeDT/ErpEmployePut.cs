﻿using Haj.Basic;
using Haj.Services;

namespace Haj.ApplicationContracts.HajEmployeDT
{
    public class HajEmployePut:BasicADEntityPut
    {
        public DateTime? DateOfBirth { get; set; }
        public DateTime? DateOfEmployment { get; set; }
        public Guid? DepartmentId { get; set; }
        public Guid? JobId { get; set; }
        public Guid? TeamId { get; set; }
        public decimal? Salary { get; set; }
        public string? Email { get; set; }
        public string? PhoneNumber { get; set; }
        public string? Address { get; set; }
        public string? NationalID { get; set; }
        public DateTime? DateOfTermination { get; set; }
        public string? EmergencyContactName { get; set; }
        public string? EmergencyContactPhone { get; set; }
        public string? BankAccountNumber { get; set; }
        public string? TaxID { get; set; }
        public int? PerformanceRating { get; set; }
        public int? YearsOfExperience { get; set; }
        public int? AttendanceScore { get; set; }
        
    }
}
