﻿using Haj.Domain;
using Haj.ApplicationContracts.AspNetUsersDT;
using Haj.ApplicationContracts.AuditableEntityDT;
using Haj.ApplicationContracts.HajEmployeContactInfoDT;
using Haj.Domain;
using System.ComponentModel.DataAnnotations.Schema;

namespace Haj.ApplicationContracts.HajEmployeDT
{
    public class HajEmployeDto: AuditableEntityDto
    {
        public string Name { get; set; } 
        public DateTime? DateOfBirth { get; set; } 
        public DateTime? DateOfEmployment { get; set; }
        public decimal? Salary { get; set; }
        public string? Email { get; set; } 
        public string? PhoneNumber { get; set; } 
        public string? Address { get; set; }
        public string? NationalID { get; set; } 
        public DateTime? DateOfTermination { get; set; } 
        public string? EmergencyContactName { get; set; } 
        public string? EmergencyContactPhone { get; set; } 
        public string? BankAccountNumber { get; set; } 
        public string? TaxID { get; set; } 
        public int? PerformanceRating { get; set; } 
        public int? YearsOfExperience { get; set; } 
        public int? AttendanceScore { get; set; }
        public Guid? EmployeUserId { get; set; }
        public ICollection<HajEmployeContactInfoDto> EmployeContactInfo { get; set; } = new List<HajEmployeContactInfoDto>();
    }
}
