﻿namespace Haj.ApplicationContracts.HajBusinessPersonDT
{
    public class HajBusinessPersonPost
    {
        public string Name { get; set; } // الاسم الكامل
        public string Email { get; set; } // البريد الإلكتروني
        public string PhoneNumber { get; set; } // رقم الهاتف
        public string Address { get; set; } // عنوان السكن
        public bool IsSupplier { get; set; }
    }
}
