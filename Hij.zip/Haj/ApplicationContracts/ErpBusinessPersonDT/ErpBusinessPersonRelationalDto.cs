﻿namespace Haj.ApplicationContracts.HajBusinessPersonDT
{
    public class HajBusinessPersonRelationalDto
    {
        public Guid Id { get; set; }
        public string Name { get; set; } // الاسم الكامل
        public bool IsSupplier { get; set; }
    }
}
