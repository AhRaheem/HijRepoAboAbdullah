﻿using Haj.ApplicationContracts.AuditableEntityDT;
using Haj.ApplicationContracts.HajBusinessPersonContactInfoDT;
using Haj.ApplicationContracts.HajEmployeContactInfoDT;

namespace Haj.ApplicationContracts.HajBusinessPersonDT
{
    public class HajBusinessPersonDto:AuditableEntityDto
    {
        public string Name { get; set; } // الاسم الكامل
        public string Email { get; set; } // البريد الإلكتروني
        public string PhoneNumber { get; set; } // رقم الهاتف
        public string Address { get; set; } // عنوان السكن
        public bool IsSupplier { get; set; }
        public ICollection<HajBusinessPersonContactInfoDto> HajBusinessPersonContactInfo { get; set; } = new List<HajBusinessPersonContactInfoDto>();
    }
}
