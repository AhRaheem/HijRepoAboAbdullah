﻿using Haj.Basic;

namespace Haj.ApplicationContracts.HajFormStatusDT
{
    public class HajFormStatusDto : BasicADEntityDto
    {
    }
}
