﻿namespace Haj.ApplicationContracts.HajFormStatusDT
{
    public class FormTypeAndStatusDto
    {
        public Guid? FormTypeId { get; set; }
        public Guid? FormStatusId { get; set; }
    }
}
