﻿using Haj.Basic;

namespace Haj.ApplicationContracts.HajCurrencyDT
{
    public class HajCurrencyPost:BasicADEntityPost
    {
    }
}
