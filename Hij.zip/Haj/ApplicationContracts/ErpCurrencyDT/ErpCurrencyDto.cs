﻿using Haj.Basic;

namespace Haj.ApplicationContracts.HajCurrencyDT
{
    public class HajCurrencyDto:BasicADEntityDto
    {
    }
}
