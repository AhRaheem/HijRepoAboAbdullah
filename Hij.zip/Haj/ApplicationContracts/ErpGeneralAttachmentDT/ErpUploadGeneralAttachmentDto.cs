﻿namespace Haj.ApplicationContracts.HajGeneralAttachmentDT
{
    public class HajUploadGeneralAttachmentDto
    {
        public string FileName { get; set; }  // Original file name
        public string ContentType { get; set; } // MIME type (e.g., "image/png")
        public string FileBase64 { get; set; }  // Base64-encoded file content
        public Guid RelatedFormId { get; set; }
        public Guid FormTypeId { get; set; }
        public string? Title { get; set; }
        public string? Description { get; set; }
    }
}
