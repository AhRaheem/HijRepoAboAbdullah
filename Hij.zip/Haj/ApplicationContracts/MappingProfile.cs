﻿using AutoMapper;
using Haj.Domain;
using Haj.ApplicationContracts.HajBusinessPersonContactInfoDT;
using Haj.ApplicationContracts.HajBusinessPersonDT;
using Haj.ApplicationContracts.HajCountryDT;
using Haj.ApplicationContracts.HajEmployeContactInfoDT;
using Haj.ApplicationContracts.HajEmployeDT;
using Haj.ApplicationContracts.HajFormStatusDT;
using Haj.ApplicationContracts.HajFormTypeActionDT;
using Haj.ApplicationContracts.HajMenuItemDT;
using Haj.ApplicationContracts.HajOrganizationStructureDT;
using Haj.ApplicationContracts.HajCurrencyDT;
using Haj.Basic;
using Haj.ApplicationContracts.AspNetUsersDT;
using Microsoft.AspNetCore.Identity;
using Haj.ApplicationContracts.AspIdentityRoleDT;
using Haj.ApplicationContracts.HajFormTypeDT;



namespace Haj.ApplicationContracts
{
    public class MappingProfile:Profile
    {
        public MappingProfile() 
        {
            #region  SharedEntities
            CreateMap<BasicADEntity, BasicADEntityDto>();
            CreateMap<BasicADEntityPost, BasicADEntity>()
                .ForMember(dest => dest.Id, opt => opt.Ignore());
            CreateMap<BasicADEntityPut, BasicADEntity>();

            CreateMap<AspNetUsers, AspNetUsersDto>();
            CreateMap<AspNetUsersPost, AspNetUsers>()
                .ForMember(dest => dest.Id, opt => opt.Ignore());
            CreateMap<AspNetUsersPut, AspNetUsers>();

            CreateMap<IdentityRole<Guid>, IdentityRoleDto>();
            CreateMap<IdentityRolePost, IdentityRole<Guid>>()
                .ForMember(dest => dest.Id, opt => opt.Ignore());
            CreateMap<IdentityRolePut, IdentityRole<Guid>>();

            CreateMap<HajMenuItem, HajMenuItemDto>();
            CreateMap<HajMenuItemPut, HajMenuItem>();
            CreateMap<HajMenuItem, ParentMenuItemDto>();

            CreateMap<HajFormStatus, HajFormStatusDto>();
            CreateMap<HajFormType, HajFormTypeDto>();
            CreateMap<HajFormTypeAction, HajFormTypeActionDto>();

            CreateMap<HajContactType, BasicADEntityDto>();
            CreateMap<BasicADEntityPost, HajContactType>()
                .ForMember(dest => dest.Id, opt => opt.Ignore());
            CreateMap<BasicADEntityPut, HajContactType>();


            CreateMap<HajCountry, HajCountryDto>();
            CreateMap<HajCountryPost, HajCountry>()
                .ForMember(dest => dest.Id, opt => opt.Ignore());
            CreateMap<HajCountryPut, HajCountry>();


            CreateMap<HajEmploye, HajEmployeDto>();
            CreateMap<HajEmployePost, HajEmploye>()
                .ForMember(dest => dest.Id, opt => opt.Ignore());
            CreateMap<HajEmployePut, HajEmploye>();

            CreateMap<HajEmployeContactInfo, HajEmployeContactInfoDto>();
            CreateMap<HajEmployeContactInfoPost, HajEmployeContactInfo>()
                .ForMember(dest => dest.Id, opt => opt.Ignore());
            CreateMap<HajEmployeContactInfoPut, HajEmployeContactInfo>();

            CreateMap<HajBusinessPerson, HajBusinessPersonDto>();
            CreateMap<HajBusinessPersonPost, HajBusinessPerson>()
                .ForMember(dest => dest.Id, opt => opt.Ignore());
            CreateMap<HajBusinessPersonPut, HajBusinessPerson>();

            CreateMap<HajBusinessPersonContactInfo, HajBusinessPersonContactInfoDto>();
            CreateMap<HajBusinessPersonContactInfoPost, HajBusinessPersonContactInfo>()
                .ForMember(dest => dest.Id, opt => opt.Ignore());
            CreateMap<HajBusinessPersonContactInfoPut, HajBusinessPersonContactInfo>();

            CreateMap<HajOrganizationStructure, HajOrganizationStructureDto>();
            CreateMap<HajOrganizationStructurePost, HajOrganizationStructure>()
                .ForMember(dest => dest.Id, opt => opt.Ignore());
            CreateMap<HajOrganizationStructurePut, HajOrganizationStructure>();


            CreateMap<HajCurrency, HajCurrencyDto>();
            CreateMap<HajCurrencyPost, HajCurrency>()
                .ForMember(dest => dest.Id, opt => opt.Ignore());
            CreateMap<HajCurrencyPut, HajCurrency>();


            #endregion
          
            #region RelationalDto
            CreateMap<HajEmploye, HajEmployeRelationalDto>();
            CreateMap<HajBusinessPerson, HajBusinessPersonRelationalDto>();
            CreateMap<HajOrganizationStructure, HajOrganizationStructureRelationalDto>();
            CreateMap<AspNetUsers, AspNetUsersRelationalDto>();
            #endregion
        }
    }
}
