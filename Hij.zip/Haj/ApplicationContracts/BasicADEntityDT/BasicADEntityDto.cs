﻿namespace Haj.Basic
{
    public class BasicADEntityDto
    {
        public Guid Id { get; set; } // معرف القسم
        public string Name { get; set; } // اسم القسم
        public bool Active { get; set; }
        public bool IsDeleted { get; set; }
    }
}
