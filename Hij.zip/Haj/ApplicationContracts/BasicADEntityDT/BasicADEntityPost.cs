﻿namespace Haj.Basic
{
    public class BasicADEntityPost
    {
        public string Name { get; set; }
    }
}
