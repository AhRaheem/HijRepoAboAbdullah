﻿using Haj.Services;

namespace Haj.ApplicationContracts.AspIdentityRoleDT
{
    public class IdentityRolePut : IHasId
    {
        public Guid Id { get; set; } 
        public string? Name { get; set; }
        public virtual string? NormalizedName { get; set; }
    }
}
