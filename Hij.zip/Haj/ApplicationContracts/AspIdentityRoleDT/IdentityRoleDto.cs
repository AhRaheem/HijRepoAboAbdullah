﻿using Microsoft.AspNetCore.Identity;

namespace Haj.ApplicationContracts.AspIdentityRoleDT
{
    public class IdentityRoleDto:IdentityRole<Guid>
    {

    }
}
