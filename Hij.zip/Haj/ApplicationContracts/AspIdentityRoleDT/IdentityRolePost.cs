﻿using Microsoft.AspNetCore.Identity;

namespace Haj.ApplicationContracts.AspIdentityRoleDT
{
    public class IdentityRolePost:IdentityRole<Guid>
    {
        public string? Name { get; set; }
        public virtual string? NormalizedName { get; set; }
    }
}
