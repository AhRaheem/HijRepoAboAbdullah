﻿using System.ComponentModel.DataAnnotations;

namespace Haj.ApplicationContracts.LicenseKeyDto
{
    public class LicenseKeyDto
    {
        [StringLength(1000)] public string? LicenseSerialKey { get; set; }
    }
}
