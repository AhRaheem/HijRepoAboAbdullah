﻿
using Haj.Services;
using System.ComponentModel.DataAnnotations;
namespace Haj.ApplicationContracts.LicenseKeyDto
{
    public class LicenseKeyPut:IHasId
    {
        public Guid Id { get; set; }
        [StringLength(1000)] public string? LicenseSerialKey { get; set; }
    }
}
