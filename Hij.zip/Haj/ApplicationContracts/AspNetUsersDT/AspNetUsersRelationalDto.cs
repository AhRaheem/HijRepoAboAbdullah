﻿namespace Haj.ApplicationContracts.AspNetUsersDT
{
    public class AspNetUsersRelationalDto
    {
        public string? UserName { get; set; }
        public string? Email { get; set; }
    }
}
