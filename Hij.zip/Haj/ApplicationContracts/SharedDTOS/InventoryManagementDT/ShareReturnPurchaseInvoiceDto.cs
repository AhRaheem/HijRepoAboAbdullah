﻿namespace Haj.ApplicationContracts.SharedDTOS.InventoryManagementDT
{
    public class ShareReturnPurchaseInvoiceDto
    {
        public Guid Id { get; set; }
        public string InvoiceNumber { get; set; }
    }
}
