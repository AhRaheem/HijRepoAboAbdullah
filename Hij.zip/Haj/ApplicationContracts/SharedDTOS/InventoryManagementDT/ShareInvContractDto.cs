﻿namespace Haj.ApplicationContracts.SharedDTOS.InventoryManagementDT
{
    public class ShareInvContractDto
    {
        public Guid Id { get; set; }
        public string ContractNumber { get; set; }
    }
}
