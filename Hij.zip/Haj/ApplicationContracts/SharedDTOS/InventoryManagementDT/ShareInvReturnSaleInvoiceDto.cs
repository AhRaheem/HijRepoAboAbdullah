﻿namespace Haj.ApplicationContracts.SharedDTOS.InventoryManagementDT
{
    public class ShareInvReturnSaleInvoiceDto
    {
        public Guid Id { get; set; }
        public string InvoiceNumber { get; set; }
    }
}
