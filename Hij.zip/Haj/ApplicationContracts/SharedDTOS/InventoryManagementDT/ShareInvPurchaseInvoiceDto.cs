﻿namespace Haj.ApplicationContracts.SharedDTOS.InventoryManagementDT
{
    public class ShareInvPurchaseInvoiceDto
    {
        public Guid Id { get; set; }
        public string InvoiceNumber { get; set; }
    }
}
