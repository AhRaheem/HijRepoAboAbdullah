﻿using Haj.Basic;

namespace Haj.ApplicationContracts.HajCountryDT
{
    public class HajCountryPut:BasicADEntityPut
    {
        public string? CountryCode { get; set; }
    }
}
