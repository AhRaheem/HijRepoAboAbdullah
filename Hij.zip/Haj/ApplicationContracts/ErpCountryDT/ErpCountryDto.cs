﻿using Haj.Basic;

namespace Haj.ApplicationContracts.HajCountryDT
{
    public class HajCountryDto:BasicADEntityDto
    {
        public string? CountryCode { get; set; }
    }
}
