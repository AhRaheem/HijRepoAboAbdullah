﻿using Haj.Basic;

namespace Haj.ApplicationContracts.HajCountryDT
{
    public class HajCountryPost:BasicADEntityPost
    {
        public string? CountryCode { get; set; }
    }
}
