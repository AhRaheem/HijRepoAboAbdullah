﻿using System.ComponentModel.DataAnnotations;

namespace Haj.ApplicationContracts.RegisterDto
{
    public class LoginDto
    {
        [Required]
        public string CompanyId { get; set; }
        [Required]
        public string Identifier { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
