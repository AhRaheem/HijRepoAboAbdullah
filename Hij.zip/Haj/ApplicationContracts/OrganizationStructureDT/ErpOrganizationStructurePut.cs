﻿using Haj.Domain;
using Haj.Basic;
using Haj.Domain.Shared.Services.enums;
using System.ComponentModel.DataAnnotations.Schema;

namespace Haj.ApplicationContracts.HajOrganizationStructureDT
{
    public class HajOrganizationStructurePut:BasicADEntityPut
    {
        public Guid? ParentorgStructId { get; set; }
        public int? Order { get; set; }
        public string? En_SiteType { get; set; }
        public string? OwnerMobileNumber { get; set; }
        public string? OwnerName { get; set; }
        public decimal? RentValue { get; set; }
        public DateTime? ContractStartDate { get; set; }
        public DateTime? ContractEndDate { get; set; }
        public string? Address { get; set; }
        public string? Phone { get; set; }
        public decimal? Area { get; set; }

    }
}
