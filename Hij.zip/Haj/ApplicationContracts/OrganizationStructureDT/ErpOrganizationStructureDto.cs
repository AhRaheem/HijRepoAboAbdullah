﻿using Haj.Domain;
using Haj.ApplicationContracts.HajEmployeDT;
using Haj.Basic;
using Haj.Domain;
using Haj.Domain.Shared.Services.enums;
using System.ComponentModel.DataAnnotations.Schema;

namespace Haj.ApplicationContracts.HajOrganizationStructureDT
{
    public class HajOrganizationStructureDto:BasicADEntityDto
    {
        public int? Order { get; set; }
        public HajOrganizationStructureRelationalDto ParentHajOrganizationStructure { get; set; }
        public string? En_SiteType { get; set; }
        public string? OwnerMobileNumber { get; set; }
        public string? OwnerName { get; set; }
        public decimal? RentValue { get; set; }
        public DateTime? ContractStartDate { get; set; }
        public DateTime? ContractEndDate { get; set; }
        public string? WarehouseAddress { get; set; }
        public string? WarehousePhone { get; set; }
        public decimal? Area { get; set; }
        public ICollection<HajOrganizationStructureRelationalDto> Children { get; set; } = new List<HajOrganizationStructureRelationalDto>();
    }
}
