﻿namespace Haj.ApplicationContracts.HajFormTypeDT
{
    public class HajFormTypeDto
    {
        public Guid Id { get; set; }
        public string Code { get; set; }
        public string NameAr { get; set; }
        public bool? Active { get; set; }
    }
}
