﻿using Haj.Domain;
using System.ComponentModel.DataAnnotations;

namespace Haj.ApplicationContracts.HajFormTypeActionDT
{
    public class HajFormTypeActionDto
    {
        public Guid Id { get; set; }
        [StringLength(100)] public string? Code { get; set; }
        [StringLength(100)] public string? NameAr { get; set; }
        [StringLength(100)] public string? NameEn { get; set; }
        [StringLength(100)] public string? ToStatusCode { get; set; }
    }
}
