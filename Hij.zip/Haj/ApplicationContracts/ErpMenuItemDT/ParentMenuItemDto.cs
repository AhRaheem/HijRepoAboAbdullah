﻿namespace Haj.ApplicationContracts.HajMenuItemDT
{
    public class ParentMenuItemDto
    {
        public Guid Id { get; set; }
        public string Name { get; set; } 
    }
}
