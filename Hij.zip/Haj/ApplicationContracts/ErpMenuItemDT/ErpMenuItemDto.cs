﻿using Haj.Basic;
using Haj.Domain;
using System.ComponentModel.DataAnnotations.Schema;

namespace Haj.ApplicationContracts.HajMenuItemDT
{
    public class HajMenuItemDto:BasicADEntityDto
    {
        public string? Url { get; set; }
        public string? Icon { get; set; }
        public int? Order { get; set; }
        public string? RequiredPermission { get; set; }
        public ParentMenuItemDto ParentMenuItem { get; set; }
        public ICollection<HajMenuItemDto> Children { get; set; } = new List<HajMenuItemDto>();
    }
}
