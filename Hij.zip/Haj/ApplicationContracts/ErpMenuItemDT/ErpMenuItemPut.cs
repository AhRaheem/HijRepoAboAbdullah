﻿
using Haj.Basic;

namespace Haj.ApplicationContracts.HajMenuItemDT
{
    public class HajMenuItemPut: BasicADEntityPut
    {
        public string? Url { get; set; }
        public string? Icon { get; set; }
        public int? Order { get; set; }
    }
}
