﻿
using Haj.Domain;
using Haj.Services;
namespace Haj.ApplicationContracts.HajBusinessPersonContactInfoDT
{
    public class HajBusinessPersonContactInfoPut:IHasId
    {
        public Guid Id { get; set; } // معرف الاتصال (ID)
        public Guid? BusinessPersonId { get; set; } // معرف الموظف
        public Guid? ContactTypeId { get; set; }
        public string ContactDetails { get; set; } // تفاصيل الاتصال
        public bool active { get; set; }
    }
}
