﻿using Haj.Domain;
using System.ComponentModel.DataAnnotations.Schema;

namespace Haj.ApplicationContracts.HajBusinessPersonContactInfoDT
{
    public class HajBusinessPersonContactInfoDto
    {
        public Guid Id { get; set; } // معرف الاتصال (ID)
        public Guid? BusinessPersonId { get; set; } // معرف الموظف
        public Guid? ContactTypeId { get; set; }
        public HajContactType ContactType { get; set; } // نوع الاتصال (هاتف، بريد إلكتروني)
        public string ContactDetails { get; set; } // تفاصيل الاتصال
        public bool IsDeleted { get; set; }
        public bool Active { get; set; }
    }
}
