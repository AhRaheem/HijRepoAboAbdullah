﻿using Haj.Domain;

namespace Haj.ApplicationContracts.HajBusinessPersonContactInfoDT
{
    public class HajBusinessPersonContactInfoPost
    {
        public Guid? BusinessPersonId { get; set; } // معرف الموظف
        public Guid? ContactTypeId { get; set; }
        public string ContactDetails { get; set; } // تفاصيل الاتصال
    }
}
