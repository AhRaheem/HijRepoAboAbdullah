﻿namespace Haj.ApplicationContracts.HajPermissions
{
    public class HajPermissionsDto
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Displayname { get; set; }
        public int Order { get; set; }
        public List<HajPermissionsDto> Children { get; set; } = new();
    }
}
